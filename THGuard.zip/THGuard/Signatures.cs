using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace THGuard
{
    public record SignatureInfo(bool Valid, string Status, string Signer, bool IsOs)
    {
        public bool Microsoft => Valid && (IsOs || Signer.Contains("Microsoft", StringComparison.OrdinalIgnoreCase));
        public string Text => Valid ? Signer : Status switch
        {
            "NotSigned" => "Sem assinatura",
            "HashMismatch" => "Assinatura ADULTERADA",
            "NotTrusted" => "Assinatura não confiável",
            "UnknownError" => "Assinatura inválida",
            "Missing" => "Arquivo não encontrado",
            _ => "Não verificado"
        };
    }

    /// <summary>
    /// Verifica a assinatura digital (Authenticode, incluindo catálogos do Windows) em lote,
    /// usando o Get-AuthenticodeSignature do próprio Windows. Resultado em cache.
    /// </summary>
    public static class Signatures
    {
        static readonly ConcurrentDictionary<string, SignatureInfo> Cache = new(StringComparer.OrdinalIgnoreCase);

        static string Key(string path)
        {
            try { return path + "|" + File.GetLastWriteTimeUtc(path).Ticks; } catch { return path; }
        }

        public static SignatureInfo? Cached(string path) => Cache.TryGetValue(Key(path), out var s) ? s : null;

        public static async Task VerifyAsync(IEnumerable<string> paths)
        {
            var todo = paths.Where(p => !string.IsNullOrWhiteSpace(p))
                            .Distinct(StringComparer.OrdinalIgnoreCase)
                            .Where(p => !Cache.ContainsKey(Key(p)))
                            .ToList();

            foreach (var missing in todo.Where(p => !File.Exists(p)).ToList())
            {
                Cache[Key(missing)] = new SignatureInfo(false, "Missing", "", false);
                todo.Remove(missing);
            }

            foreach (var chunk in todo.Chunk(150))
            {
                string list = Path.Combine(Path.GetTempPath(), $"thguard_sig_{Guid.NewGuid():N}.txt");
                File.WriteAllLines(list, chunk, new UTF8Encoding(false));
                string script =
                    $"$files = Get-Content -LiteralPath '{list}' -Encoding UTF8; " +
                    "$r = foreach ($f in $files) { try { $s = Get-AuthenticodeSignature -LiteralPath $f -ErrorAction Stop; " +
                    "$n = ''; if ($s.SignerCertificate) { $n = $s.SignerCertificate.GetNameInfo('SimpleName', $false) }; " +
                    "[pscustomobject]@{ P = $f; S = [string]$s.Status; N = $n; O = [bool]$s.IsOSBinary } } " +
                    "catch { [pscustomobject]@{ P = $f; S = 'Error'; N = ''; O = $false } } }; " +
                    "@($r) | ConvertTo-Json -Compress";
                var (_, output) = await Shell.PowerShellAsync(script, 180000);
                try { File.Delete(list); } catch { }

                int start = output.IndexOfAny(new[] { '[', '{' });
                if (start < 0) continue;
                try
                {
                    using var doc = JsonDocument.Parse(output[start..]);
                    var items = doc.RootElement.ValueKind == JsonValueKind.Array
                        ? doc.RootElement.EnumerateArray().ToList()
                        : new List<JsonElement> { doc.RootElement };
                    foreach (var e in items)
                    {
                        string p = e.GetProperty("P").GetString() ?? "";
                        string st = e.GetProperty("S").GetString() ?? "";
                        string n = e.TryGetProperty("N", out var nn) ? nn.GetString() ?? "" : "";
                        bool os = e.TryGetProperty("O", out var oo) && oo.ValueKind == JsonValueKind.True;
                        Cache[Key(p)] = new SignatureInfo(st == "Valid", st, n, os);
                    }
                }
                catch { }
            }
        }

        public static async Task<SignatureInfo> VerifyOneAsync(string path)
        {
            await VerifyAsync(new[] { path });
            return Cached(path) ?? new SignatureInfo(false, "Unknown", "", false);
        }

        public static string Sha256(string path)
        {
            try
            {
                using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
                return Convert.ToHexString(SHA256.HashData(fs)).ToLowerInvariant();
            }
            catch { return ""; }
        }
    }
}
