using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace THGuard
{
    /// <summary>
    /// Quarentena reversível. Arquivos são embaralhados (XOR) para não poderem ser executados
    /// e guardados em %ProgramData%\THGuard\Quarantine. Entradas de inicialização são desativadas
    /// guardando o valor original para poder restaurar.
    /// </summary>
    public static class Quarantine
    {
        const byte Key = 0xA5;
        public static string Dir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "THGuard", "Quarantine");
        static string IndexFile => Path.Combine(Dir, "index.json");

        public static List<QuarantineItem> Load()
        {
            try
            {
                if (File.Exists(IndexFile))
                    return JsonSerializer.Deserialize<List<QuarantineItem>>(File.ReadAllText(IndexFile)) ?? new();
            }
            catch { }
            return new();
        }

        static void Save(List<QuarantineItem> items)
        {
            Directory.CreateDirectory(Dir);
            File.WriteAllText(IndexFile, JsonSerializer.Serialize(items, new JsonSerializerOptions { WriteIndented = true }));
        }

        static void Add(QuarantineItem item)
        {
            var list = Load();
            list.Add(item);
            Save(list);
        }

        // ------------------------------------------------------------- arquivos

        public static void KillByPath(string path)
        {
            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    string? exe = Native.ProcessPath(p.Id);
                    if (exe != null && exe.Equals(path, StringComparison.OrdinalIgnoreCase)) { p.Kill(true); p.WaitForExit(3000); }
                }
                catch { }
                finally { p.Dispose(); }
            }
        }

        public static async Task<(bool Ok, string Message)> QuarantineFileAsync(string path, string reason)
        {
            if (!File.Exists(path)) return (false, "Arquivo não encontrado.");
            if (Rules.InWindows(path)) return (false, "Arquivos da pasta do Windows não são colocados em quarentena por segurança.");

            return await Task.Run(() =>
            {
                try
                {
                    KillByPath(path);
                    Directory.CreateDirectory(Dir);
                    string id = Guid.NewGuid().ToString("N");
                    byte[] data = File.ReadAllBytes(path);
                    string hash = Signatures.Sha256(path);
                    for (int i = 0; i < data.Length; i++) data[i] ^= Key;
                    File.WriteAllBytes(Path.Combine(Dir, id + ".qtn"), data);

                    File.SetAttributes(path, FileAttributes.Normal);
                    File.Delete(path);

                    Add(new QuarantineItem
                    {
                        Id = id, Kind = "Arquivo", OriginalPath = path, Name = Path.GetFileName(path),
                        Reason = reason, Sha256 = hash, Date = DateTime.Now, Size = data.Length
                    });
                    return (true, "Arquivo colocado em quarentena.");
                }
                catch (Exception ex) { return (false, "Não foi possível: " + ex.Message); }
            });
        }

        // --------------------------------------------------------- inicialização

        public static async Task<(bool Ok, string Message)> DisableStartupAsync(StartupEntry e, string reason)
        {
            try
            {
                if (e.TaskName.Length > 0)
                {
                    var (code, _) = await Shell.RunAsync("schtasks.exe", $"/Change /TN \"{e.TaskName}\" /Disable");
                    if (code != 0) return (false, "Não foi possível desativar a tarefa.");
                    Add(new QuarantineItem { Id = Guid.NewGuid().ToString("N"), Kind = "Tarefa", Name = e.Name, TaskName = e.TaskName, OriginalPath = e.Command, Reason = reason, Date = DateTime.Now });
                    e.Enabled = false;
                    return (true, "Tarefa desativada.");
                }

                if (e.ServiceName.Length > 0)
                {
                    using var k = Registry.LocalMachine.OpenSubKey($@"SYSTEM\CurrentControlSet\Services\{e.ServiceName}", true);
                    if (k == null) return (false, "Serviço não encontrado.");
                    int start = k.GetValue("Start") is int s ? s : 2;
                    k.SetValue("Start", 4, RegistryValueKind.DWord);
                    await Shell.RunAsync("sc.exe", $"stop \"{e.ServiceName}\"");
                    Add(new QuarantineItem { Id = Guid.NewGuid().ToString("N"), Kind = "Serviço", Name = e.Name, ServiceName = e.ServiceName, ServiceStart = start, OriginalPath = e.Command, Reason = reason, Date = DateTime.Now });
                    e.Enabled = false;
                    return (true, "Serviço desativado.");
                }

                if (e.RegValue.Length > 0)
                {
                    var hive = e.RegHive == "HKCU" ? Registry.CurrentUser : Registry.LocalMachine;
                    using var k = hive.OpenSubKey(e.RegKey, true);
                    if (k == null) return (false, "Chave não encontrada.");
                    string data = k.GetValue(e.RegValue)?.ToString() ?? "";
                    k.DeleteValue(e.RegValue, false);
                    Add(new QuarantineItem
                    {
                        Id = Guid.NewGuid().ToString("N"), Kind = "Registro", Name = e.Name, RegHive = e.RegHive, RegKey = e.RegKey,
                        RegValue = e.RegValue, RegData = data, OriginalPath = data, Reason = reason, Date = DateTime.Now
                    });
                    e.Enabled = false;
                    return (true, "Entrada de inicialização removida (pode ser restaurada na Quarentena).");
                }

                if (e.Source == "Pasta Inicializar" && File.Exists(e.Location))
                {
                    var r = await QuarantineFileAsync(e.Location, reason);
                    if (r.Ok) e.Enabled = false;
                    return r;
                }
            }
            catch (Exception ex) { return (false, ex.Message); }
            return (false, "Esse tipo de entrada não pode ser desativado aqui.");
        }

        // ------------------------------------------------------------ restaurar

        public static async Task<(bool Ok, string Message)> RestoreAsync(QuarantineItem item)
        {
            try
            {
                switch (item.Kind)
                {
                    case "Arquivo":
                        string src = Path.Combine(Dir, item.Id + ".qtn");
                        if (!File.Exists(src)) return (false, "O arquivo da quarentena sumiu.");
                        if (File.Exists(item.OriginalPath)) return (false, "Já existe um arquivo no local original.");
                        byte[] data = await File.ReadAllBytesAsync(src);
                        for (int i = 0; i < data.Length; i++) data[i] ^= Key;
                        Directory.CreateDirectory(Path.GetDirectoryName(item.OriginalPath)!);
                        await File.WriteAllBytesAsync(item.OriginalPath, data);
                        File.Delete(src);
                        break;
                    case "Registro":
                        var hive = item.RegHive == "HKCU" ? Registry.CurrentUser : Registry.LocalMachine;
                        using (var k = hive.CreateSubKey(item.RegKey, true))
                            k.SetValue(item.RegValue, item.RegData, RegistryValueKind.String);
                        break;
                    case "Tarefa":
                        await Shell.RunAsync("schtasks.exe", $"/Change /TN \"{item.TaskName}\" /Enable");
                        break;
                    case "Serviço":
                        using (var k = Registry.LocalMachine.OpenSubKey($@"SYSTEM\CurrentControlSet\Services\{item.ServiceName}", true))
                            k?.SetValue("Start", item.ServiceStart, RegistryValueKind.DWord);
                        break;
                }
                Remove(item, deleteFile: false);
                return (true, $"{item.Name} restaurado.");
            }
            catch (Exception ex) { return (false, ex.Message); }
        }

        public static void Remove(QuarantineItem item, bool deleteFile = true)
        {
            if (deleteFile)
            {
                try { File.Delete(Path.Combine(Dir, item.Id + ".qtn")); } catch { }
            }
            var list = Load();
            list.RemoveAll(x => x.Id == item.Id);
            Save(list);
        }
    }

    /// <summary>Correções de configurações do sistema.</summary>
    public static class Fixes
    {
        public static async Task<(bool Ok, string Message)> ApplyAsync(Finding f)
        {
            try
            {
                switch (f.Fix)
                {
                    case FixKind.KillProcess:
                        try { using var p = Process.GetProcessById(f.Pid); p.Kill(true); } catch { }
                        return (true, "Processo encerrado.");

                    case FixKind.Quarantine:
                        if (f.Pid > 0) { try { using var p = Process.GetProcessById(f.Pid); p.Kill(true); p.WaitForExit(3000); } catch { } }
                        return await Quarantine.QuarantineFileAsync(f.Path, f.Title);

                    case FixKind.DisableStartup when f.Tag is StartupEntry e:
                        return await Quarantine.DisableStartupAsync(e, f.Title);

                    case FixKind.RemoveWmi when f.Tag is StartupEntry w:
                        string n = w.Name.Replace("'", "''");
                        await Shell.PowerShellAsync(
                            $"Get-WmiObject -Namespace root\\subscription -Class __FilterToConsumerBinding | Where-Object {{ $_.Consumer -like '*{n}*' }} | Remove-WmiObject; " +
                            $"Get-WmiObject -Namespace root\\subscription -Class __EventConsumer | Where-Object {{ $_.Name -eq '{n}' }} | Remove-WmiObject");
                        return (true, "Assinatura WMI removida.");

                    case FixKind.RemoveExclusion when f.Tag is ValueTuple<string, string> ex:
                        string param = ex.Item1 switch { "Processo" => "ExclusionProcess", "Extensão" => "ExclusionExtension", _ => "ExclusionPath" };
                        var (code, _) = await Shell.PowerShellAsync($"Remove-MpPreference -{param} '{ex.Item2.Replace("'", "''")}' -ErrorAction Stop");
                        return code == 0 ? (true, "Exclusão removida.") : (false, "Não foi possível (a Proteção contra adulteração pode bloquear; remova em Segurança do Windows).");

                    case FixKind.EnableRealtime:
                        var r1 = await Shell.PowerShellAsync("Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction Stop");
                        return r1.Code == 0 ? (true, "Proteção em tempo real ligada.") : (false, "Ligue em Segurança do Windows > Proteção contra vírus e ameaças.");

                    case FixKind.UpdateSignatures:
                        var up = await Defender.UpdateAsync(null);
                        return up.Code == 0 ? (true, "Definições atualizadas.") : (false, "Não foi possível atualizar agora.");

                    case FixKind.EnablePua:
                        var r2 = await Shell.PowerShellAsync("Set-MpPreference -PUAProtection Enabled -ErrorAction Stop");
                        return r2.Code == 0 ? (true, "Bloqueio de apps indesejados ligado.") : (false, "Não foi possível ligar.");

                    case FixKind.EnableFirewall:
                        var r3 = await Shell.RunAsync("netsh.exe", "advfirewall set allprofiles state on");
                        return r3.Code == 0 ? (true, "Firewall ligado.") : (false, "Não foi possível ligar o firewall.");

                    case FixKind.EnableUac:
                        using (var k = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", true))
                            k.SetValue("EnableLUA", 1, RegistryValueKind.DWord);
                        return (true, "UAC ligado. Reinicie o PC para valer.");

                    case FixKind.EnableSmartScreen:
                        using (var k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows\System", true))
                            k?.DeleteValue("EnableSmartScreen", false);
                        using (var k = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", true))
                            k.SetValue("SmartScreenEnabled", "Warn", RegistryValueKind.String);
                        return (true, "SmartScreen ligado.");

                    case FixKind.DisableProxy:
                        using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Internet Settings", true))
                        {
                            k.SetValue("ProxyEnable", 0, RegistryValueKind.DWord);
                            k.DeleteValue("AutoConfigURL", false);
                        }
                        return (true, "Proxy desativado.");

                    case FixKind.CleanHosts:
                        return CleanHosts();
                }
            }
            catch (Exception ex) { return (false, ex.Message); }
            return (false, "Nenhuma correção disponível.");
        }

        static (bool, string) CleanHosts()
        {
            string hosts = SystemChecks.HostsPath;
            var bad = SystemChecks.SuspiciousHostsLines();
            if (bad.Count == 0) return (true, "Nada para limpar.");
            Directory.CreateDirectory(Settings.DataDir);
            string backup = Path.Combine(Settings.DataDir, $"hosts_{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.bak");
            File.Copy(hosts, backup, true);

            var keep = new List<string>();
            foreach (var raw in File.ReadAllLines(hosts))
            {
                string line = raw.Split('#')[0].Trim();
                var parts = line.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
                bool remove = parts.Length >= 2 && parts.Skip(1).Any(h => bad.Contains($"{parts[0]} {h}"));
                keep.Add(remove ? "# removido pelo TH Guard: " + raw : raw);
            }
            File.SetAttributes(hosts, FileAttributes.Normal);
            File.WriteAllLines(hosts, keep, new UTF8Encoding(false));
            return (true, $"Hosts limpo. Backup salvo em {backup}");
        }
    }
}
