using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Threading.Tasks;

namespace THGuard
{
    public record ProcSnap(int Pid, int ParentPid, string Name, string Path, string CommandLine);

    /// <summary>Mede o uso de CPU e GPU de cada processo entre duas leituras.</summary>
    public sealed class UsageSampler : IDisposable
    {
        readonly Dictionary<int, (TimeSpan Cpu, DateTime Time)> _last = new();
        List<(int Pid, PerformanceCounter Counter)>? _gpu;
        DateTime _gpuRefresh;
        public Dictionary<int, double> Cpu { get; private set; } = new();
        public Dictionary<int, double> Gpu { get; private set; } = new();
        public Dictionary<int, double> MemoryMB { get; private set; } = new();

        public void Sample()
        {
            var now = DateTime.UtcNow;
            var cpu = new Dictionary<int, double>();
            var mem = new Dictionary<int, double>();
            int cores = Environment.ProcessorCount;
            var seen = new HashSet<int>();
            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    seen.Add(p.Id);
                    mem[p.Id] = p.WorkingSet64 / 1024.0 / 1024.0;
                    var t = p.TotalProcessorTime;
                    if (_last.TryGetValue(p.Id, out var prev))
                    {
                        double secs = (now - prev.Time).TotalSeconds;
                        if (secs > 0) cpu[p.Id] = Math.Clamp((t - prev.Cpu).TotalSeconds / secs / cores * 100, 0, 100);
                    }
                    _last[p.Id] = (t, now);
                }
                catch { }
                finally { p.Dispose(); }
            }
            foreach (var dead in _last.Keys.Where(k => !seen.Contains(k)).ToList()) _last.Remove(dead);
            Cpu = cpu;
            MemoryMB = mem;
            SampleGpu();
        }

        void SampleGpu()
        {
            try
            {
                if (_gpu == null || (DateTime.UtcNow - _gpuRefresh).TotalSeconds > 15)
                {
                    _gpu?.ForEach(x => x.Counter.Dispose());
                    _gpu = new();
                    var cat = new PerformanceCounterCategory("GPU Engine");
                    foreach (var name in cat.GetInstanceNames())
                    {
                        string n = name.ToLowerInvariant();
                        if (!(n.Contains("engtype_3d") || n.Contains("engtype_compute") || n.Contains("engtype_cuda"))) continue;
                        int i = n.IndexOf("pid_", StringComparison.Ordinal);
                        if (i < 0) continue;
                        int j = n.IndexOf('_', i + 4);
                        if (j < 0 || !int.TryParse(n[(i + 4)..j], out int pid)) continue;
                        var c = new PerformanceCounter("GPU Engine", "Utilization Percentage", name, true);
                        try { c.NextValue(); } catch { }
                        _gpu.Add((pid, c));
                    }
                    _gpuRefresh = DateTime.UtcNow;
                    return;
                }
                var gpu = new Dictionary<int, double>();
                foreach (var (pid, c) in _gpu)
                {
                    try { gpu[pid] = Math.Min(100, gpu.GetValueOrDefault(pid) + c.NextValue()); } catch { }
                }
                Gpu = gpu;
            }
            catch { Gpu = new(); }
        }

        public void Dispose() => _gpu?.ForEach(x => x.Counter.Dispose());
    }

    public static class ProcessScanner
    {
        static readonly HashSet<string> ScriptHosts = new(StringComparer.OrdinalIgnoreCase)
        {
            "powershell", "pwsh", "cmd", "wscript", "cscript", "mshta", "rundll32", "regsvr32", "certutil", "bitsadmin", "wmic"
        };

        /// <summary>Lista processos com caminho e linha de comando (WMI).</summary>
        public static List<ProcSnap> Snapshot()
        {
            var list = new List<ProcSnap>();
            try
            {
                using var searcher = new ManagementObjectSearcher("SELECT ProcessId, ParentProcessId, Name, ExecutablePath, CommandLine FROM Win32_Process");
                foreach (ManagementObject mo in searcher.Get())
                {
                    using (mo)
                    {
                        int pid = Convert.ToInt32(mo["ProcessId"]);
                        if (pid <= 4 || pid == Environment.ProcessId) continue;
                        string path = mo["ExecutablePath"] as string ?? Native.ProcessPath(pid) ?? "";
                        list.Add(new ProcSnap(pid, Convert.ToInt32(mo["ParentProcessId"]), mo["Name"] as string ?? "",
                                              path, mo["CommandLine"] as string ?? ""));
                    }
                }
            }
            catch
            {
                foreach (var p in Process.GetProcesses())
                {
                    try
                    {
                        if (p.Id > 4 && p.Id != Environment.ProcessId)
                            list.Add(new ProcSnap(p.Id, 0, p.ProcessName + ".exe", Native.ProcessPath(p.Id) ?? "", ""));
                    }
                    catch { }
                    finally { p.Dispose(); }
                }
            }
            return list;
        }

        /// <summary>Avalia um processo e devolve o risco e os motivos.</summary>
        public static (Severity Risk, List<string> Reasons) Evaluate(ProcSnap p, SignatureInfo? sig, double cpu, double gpu,
            bool hasWindow, IEnumerable<Native.TcpConn> conns, bool sustained, Settings s)
        {
            var reasons = new List<string>();
            var risk = Severity.Info;
            void Hit(Severity sv, string why) { reasons.Add(why); if (sv > risk) risk = sv; }

            string baseName = System.IO.Path.GetFileNameWithoutExtension(p.Name);
            bool signed = sig?.Valid == true;
            bool microsoft = sig?.Microsoft == true;

            // Mineração
            if (Rules.IsMinerName(p.Name) || Rules.IsMinerName(p.Path))
                Hit(signed ? Severity.Medium : Severity.High, "nome de programa minerador conhecido");
            var minerCmd = Rules.MinerCommand(p.CommandLine);
            if (minerCmd != null) Hit(Severity.High, minerCmd);

            var mining = conns.Where(c => c.Pid == p.Pid && c.Established && Rules.MiningPorts.Contains(c.RemotePort)).ToList();
            if (mining.Count > 0)
                Hit(minerCmd != null ? Severity.High : Severity.Medium,
                    $"conectado a porta usada por pools de mineração ({mining[0].Remote}:{mining[0].RemotePort})");

            // Disfarce de processo do Windows
            var masq = Rules.Masquerade(p.Name, p.Path);
            if (masq != null) Hit(masq.Contains("parecido") ? Severity.Medium : Severity.High, masq);

            if (Rules.DoubleExtension(p.Path)) Hit(Severity.High, "arquivo com extensão dupla (truque para parecer documento)");

            // Comandos de script suspeitos
            var script = Rules.SuspiciousScript(p.CommandLine);
            if (script != null) Hit(ScriptHosts.Contains(baseName) ? Severity.High : Severity.Medium, script);

            // Assinatura
            if (sig?.Status == "HashMismatch") Hit(Severity.High, "assinatura digital adulterada");

            // Local suspeito
            var folder = Rules.SuspiciousFolder(p.Path);
            if (folder != null && !signed) Hit(Rules.InTemp(p.Path) ? Severity.Medium : Severity.Low, $"roda da {folder} sem assinatura digital");

            // Uso alto sem janela
            if (!microsoft && !hasWindow && sustained)
            {
                if (cpu >= s.MinerCpuThreshold)
                    Hit(!signed ? Severity.Medium : Severity.Low, $"usa {cpu:0}% da CPU sem ter janela aberta");
                if (gpu >= s.MinerGpuThreshold)
                    Hit(!signed ? Severity.High : Severity.Medium, $"usa {gpu:0}% da placa de vídeo sem ter janela aberta");
            }

            // Combinação: sem assinatura + local suspeito + uso alto = muito provável minerador
            if (!signed && folder != null && sustained && (cpu >= s.MinerCpuThreshold || gpu >= s.MinerGpuThreshold))
                Hit(Severity.High, "combinação típica de minerador escondido");

            return (risk, reasons);
        }

        /// <summary>Verificação de processos usada na verificação inteligente.</summary>
        public static async Task<List<Finding>> ScanAsync(Settings s, IProgress<string> log)
        {
            log.Report("Lendo processos em execução...");
            var snaps = await Task.Run(() => Snapshot());
            log.Report($"{snaps.Count} processos. Verificando assinaturas digitais...");
            await Signatures.VerifyAsync(snaps.Select(p => p.Path));

            log.Report("Medindo uso de CPU e placa de vídeo...");
            using var sampler = new UsageSampler();
            await Task.Run(sampler.Sample);
            await Task.Delay(3000);
            await Task.Run(sampler.Sample);

            var conns = Native.TcpConnections();
            var windows = Native.WindowPids();
            var findings = new List<Finding>();

            foreach (var p in snaps)
            {
                var sig = Signatures.Cached(p.Path);
                double cpu = sampler.Cpu.GetValueOrDefault(p.Pid), gpu = sampler.Gpu.GetValueOrDefault(p.Pid);
                bool high = cpu >= s.MinerCpuThreshold || gpu >= s.MinerGpuThreshold;
                var (risk, reasons) = Evaluate(p, sig, cpu, gpu, windows.Contains(p.Pid), conns, high, s);
                if (risk < Severity.Low) continue;

                bool canQuarantine = p.Path.Length > 0 && sig?.Microsoft != true && !Rules.InWindows(p.Path);
                findings.Add(new Finding
                {
                    Severity = risk,
                    Category = "Processo",
                    Title = $"{p.Name} (PID {p.Pid})",
                    Detail = Capitalize(string.Join("; ", reasons)) + $".\nAssinatura: {sig?.Text ?? "não verificada"}",
                    Path = p.Path,
                    Pid = p.Pid,
                    Key = "proc:" + (p.Path.Length > 0 ? p.Path : p.Name).ToLowerInvariant(),
                    Fix = canQuarantine ? FixKind.Quarantine : FixKind.KillProcess,
                    FixLabel = canQuarantine ? "Encerrar e pôr em quarentena" : "Encerrar processo",
                });
            }
            log.Report($"Processos: {findings.Count} alertas.");
            return findings;
        }

        public static string Capitalize(string s) => s.Length == 0 ? s : char.ToUpper(s[0]) + s[1..];
    }
}
