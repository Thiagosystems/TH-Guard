using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace THGuard
{
    /// <summary>Listas e regras usadas pelas verificações heurísticas.</summary>
    public static class Rules
    {
        public static readonly HashSet<string> MinerNames = new(StringComparer.OrdinalIgnoreCase)
        {
            "xmrig", "xmrig-notls", "xmrig-cuda", "xmr-stak", "xmrstak", "nicehashminer", "nicehash", "excavator",
            "phoenixminer", "t-rex", "trex", "lolminer", "nbminer", "gminer", "miner", "ethminer", "cgminer",
            "bfgminer", "teamredminer", "srbminer", "srbminer-multi", "wildrig", "cpuminer", "cpuminer-opt",
            "ccminer", "claymore", "ethdcrminer64", "minerd", "minergate", "nanominer", "rigel", "bzminer",
            "onezerominer", "kawpowminer", "z-enemy", "nheqminer", "xmrminer", "monerominer"
        };

        public static readonly string[] PoolHints =
        {
            "stratum+tcp", "stratum+ssl", "stratum2+tcp", "stratum://", "minexmr", "supportxmr", "nanopool", "2miners",
            "f2pool", "ethermine", "hashvault", "moneroocean", "c3pool", "unmineable", "herominers", "nicehash.com",
            "miningpoolhub", "zpool", "prohashing", "kryptex", "woolypooly", "flypool", "xmrpool", "dwarfpool",
            "minergate", "hashcity", "monerohash", "xmrfast", "bitfly", "viabtc", "antpool", "poolin", "k1pool"
        };

        public static readonly string[] MinerArgs =
        {
            "--donate-level", "--cpu-priority", "--randomx", "-a rx/0", "--algo=rx", "--algo rx", "-a cn/", "--coin monero",
            "--coin=monero", "--cuda", "--opencl", "--max-cpu-usage", "--cpu-max-threads-hint", "-o pool.", "--pool ",
            "--user 4", "-u 4", "--nicehash", "--rig-id", "--background", "--no-color --donate"
        };

        static readonly Regex MoneroWallet = new(@"\b4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}\b", RegexOptions.Compiled);
        static readonly Regex EthWallet = new(@"\b0x[a-fA-F0-9]{40}\b", RegexOptions.Compiled);

        public static readonly HashSet<int> MiningPorts = new()
        {
            3333, 3334, 3357, 4444, 5555, 5556, 6666, 7777, 8888, 9999, 10343, 14433, 14444, 15555, 20535, 20580,
            45560, 45700, 1800, 2222, 13333, 17777, 18081
        };

        /// <summary>Processos do Windows e a pasta onde devem estar.</summary>
        public static readonly Dictionary<string, string> SystemProcesses = new(StringComparer.OrdinalIgnoreCase)
        {
            ["svchost"] = "system32", ["lsass"] = "system32", ["csrss"] = "system32", ["winlogon"] = "system32",
            ["services"] = "system32", ["smss"] = "system32", ["wininit"] = "system32", ["taskhostw"] = "system32",
            ["dwm"] = "system32", ["conhost"] = "system32", ["spoolsv"] = "system32", ["sihost"] = "system32",
            ["fontdrvhost"] = "system32", ["dllhost"] = "system32|syswow64", ["rundll32"] = "system32|syswow64",
            ["explorer"] = "windows", ["taskmgr"] = "system32", ["ctfmon"] = "system32", ["searchindexer"] = "system32",
            ["msmpeng"] = "windows defender|platform", ["runtimebroker"] = "system32", ["lsaiso"] = "system32"
        };

        static readonly string[] ScriptRed =
        {
            "-enc ", "-encodedcommand", "-e jab", "frombase64string", "downloadstring", "downloadfile", "invoke-expression",
            "iex(", "iex (", "-w hidden", "-windowstyle hidden", "bitsadmin /transfer", "certutil -urlcache",
            "certutil.exe -urlcache", "mshta http", "mshta.exe http", "javascript:", "vbscript:", "regsvr32 /s /n /u /i:http",
            "/i:http", "add-mppreference -exclusion", "set-mppreference -disable", "net.webclient", "start-bitstransfer"
        };

        static readonly string[] DangerousExt = { ".exe", ".scr", ".com", ".pif", ".bat", ".cmd", ".vbs", ".js", ".jse", ".wsf", ".hta", ".ps1", ".lnk" };
        static readonly string[] DecoyExt = { ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".jpg", ".jpeg", ".png", ".mp4", ".mp3", ".txt", ".zip", ".rar" };

        // ------------------------------------------------------------ caminhos

        static readonly string Win = Environment.GetFolderPath(Environment.SpecialFolder.Windows).TrimEnd('\\') + "\\";
        static readonly string Temp = Path.GetTempPath();
        static readonly string Local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\";
        static readonly string Roaming = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\";
        static readonly string ProgData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\";
        static readonly string Profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\";
        static readonly string PF = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + "\\";
        static readonly string PF86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + "\\";

        public static bool InWindows(string p) => p.StartsWith(Win, StringComparison.OrdinalIgnoreCase);
        public static bool InProgramFiles(string p) =>
            p.StartsWith(PF, StringComparison.OrdinalIgnoreCase) || p.StartsWith(PF86, StringComparison.OrdinalIgnoreCase);

        public static bool InTemp(string p) =>
            p.StartsWith(Temp, StringComparison.OrdinalIgnoreCase)
            || p.StartsWith(Win + "Temp\\", StringComparison.OrdinalIgnoreCase)
            || p.Contains("\\$Recycle.Bin\\", StringComparison.OrdinalIgnoreCase);

        /// <summary>Pastas onde qualquer programa pode gravar (lugares comuns de malware).</summary>
        public static string? SuspiciousFolder(string p)
        {
            if (string.IsNullOrEmpty(p)) return null;
            if (InTemp(p)) return "pasta temporária";
            if (p.StartsWith(Profile + "Downloads\\", StringComparison.OrdinalIgnoreCase)) return "pasta Downloads";
            if (p.StartsWith(@"C:\Users\Public\", StringComparison.OrdinalIgnoreCase)) return "pasta Pública";
            string? dir = Path.GetDirectoryName(p);
            if (dir != null && (dir + "\\").Equals(Roaming, StringComparison.OrdinalIgnoreCase)) return "raiz do AppData\\Roaming";
            if (dir != null && (dir + "\\").Equals(ProgData, StringComparison.OrdinalIgnoreCase)) return "raiz do ProgramData";
            if (dir != null && (dir + "\\").Equals(Local, StringComparison.OrdinalIgnoreCase)) return "raiz do AppData\\Local";
            return null;
        }

        public static bool UserWritable(string p) =>
            p.StartsWith(Profile, StringComparison.OrdinalIgnoreCase) || p.StartsWith(ProgData, StringComparison.OrdinalIgnoreCase)
            || p.StartsWith(@"C:\Users\Public\", StringComparison.OrdinalIgnoreCase) || InTemp(p);

        // ------------------------------------------------------------- testes

        public static bool IsMinerName(string name) =>
            MinerNames.Contains(System.IO.Path.GetFileNameWithoutExtension(name));

        /// <summary>Retorna o motivo se a linha de comando parecer de mineração.</summary>
        public static string? MinerCommand(string cmd)
        {
            if (string.IsNullOrEmpty(cmd)) return null;
            string c = cmd.ToLowerInvariant();
            var pool = PoolHints.FirstOrDefault(h => c.Contains(h));
            if (pool != null) return $"conecta a pool de mineração ({pool})";
            var arg = MinerArgs.FirstOrDefault(a => c.Contains(a));
            if (arg != null) return $"usa parâmetro típico de minerador ({arg.Trim()})";
            if (MoneroWallet.IsMatch(cmd)) return "contém endereço de carteira Monero";
            if (EthWallet.IsMatch(cmd) && (c.Contains(" -u ") || c.Contains("--user") || c.Contains("wallet"))) return "contém endereço de carteira de criptomoeda";
            return null;
        }

        /// <summary>Comandos de script usados por malware (download, código escondido...).</summary>
        public static string? SuspiciousScript(string cmd)
        {
            if (string.IsNullOrEmpty(cmd)) return null;
            string c = cmd.ToLowerInvariant();
            var hit = ScriptRed.FirstOrDefault(r => c.Contains(r));
            return hit == null ? null : $"comando suspeito: \"{hit.Trim()}\"";
        }

        /// <summary>Nome de processo do Windows rodando fora da pasta certa.</summary>
        public static string? Masquerade(string name, string path)
        {
            if (string.IsNullOrEmpty(path)) return null;
            string n = System.IO.Path.GetFileNameWithoutExtension(name);
            if (SystemProcesses.TryGetValue(n, out var where))
            {
                string p = path.ToLowerInvariant();
                bool ok = where.Split('|').Any(w => w == "windows"
                    ? System.IO.Path.GetDirectoryName(p)?.TrimEnd('\\') == Win.TrimEnd('\\').ToLowerInvariant()
                    : p.Contains("\\" + w + "\\") || p.Contains("\\" + w));
                if (!ok) return $"usa o nome de um processo do Windows ({n}.exe) mas está em outra pasta";
                return null;
            }
            // Nomes quase iguais (scvhost, svch0st, lsasss...)
            foreach (var sys in SystemProcesses.Keys)
                if (n.Length >= 5 && !n.Equals(sys, StringComparison.OrdinalIgnoreCase) && Distance(n.ToLowerInvariant(), sys) == 1)
                    return $"nome parecido com o processo do Windows \"{sys}.exe\"";
            return null;
        }

        /// <summary>Arquivo com extensão dupla (ex.: boleto.pdf.exe).</summary>
        public static bool DoubleExtension(string path)
        {
            string file = System.IO.Path.GetFileName(path).ToLowerInvariant();
            string ext = System.IO.Path.GetExtension(file);
            if (!DangerousExt.Contains(ext)) return false;
            string inner = System.IO.Path.GetExtension(System.IO.Path.GetFileNameWithoutExtension(file));
            return DecoyExt.Contains(inner) || file.Contains("      ");
        }

        public static bool IsExecutable(string path) => DangerousExt.Contains(System.IO.Path.GetExtension(path).ToLowerInvariant())
                                                        || path.EndsWith(".dll", StringComparison.OrdinalIgnoreCase);

        static int Distance(string a, string b)
        {
            var d = new int[a.Length + 1, b.Length + 1];
            for (int i = 0; i <= a.Length; i++) d[i, 0] = i;
            for (int j = 0; j <= b.Length; j++) d[0, j] = j;
            for (int i = 1; i <= a.Length; i++)
                for (int j = 1; j <= b.Length; j++)
                {
                    d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
                    // letras trocadas de lugar (scvhost) contam como 1 erro
                    if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1])
                        d[i, j] = Math.Min(d[i, j], d[i - 2, j - 2] + 1);
                }
            return d[a.Length, b.Length];
        }

        /// <summary>Extrai o caminho do executável de uma linha de comando.</summary>
        public static string ExtractPath(string command)
        {
            if (string.IsNullOrWhiteSpace(command)) return "";
            string c = Environment.ExpandEnvironmentVariables(command.Trim());
            string exe;
            if (c.StartsWith("\""))
            {
                int end = c.IndexOf('"', 1);
                exe = end > 0 ? c[1..end] : c.Trim('"');
            }
            else
            {
                var m = Regex.Match(c, @"^(.+?\.(exe|com|bat|cmd|vbs|js|ps1|scr|dll|lnk|hta))(\s|,|$)", RegexOptions.IgnoreCase);
                exe = m.Success ? m.Groups[1].Value : c.Split(' ')[0];
            }

            // rundll32 / regsvr32: o alvo é a DLL
            string fn = System.IO.Path.GetFileNameWithoutExtension(exe).ToLowerInvariant();
            if (fn is "rundll32" or "regsvr32")
            {
                var dll = Regex.Match(c, @"[""]?([a-z]:\\[^"",]+?\.dll)", RegexOptions.IgnoreCase);
                if (dll.Success) exe = dll.Groups[1].Value;
            }

            if (exe.StartsWith(@"\??\")) exe = exe[4..];
            if (exe.StartsWith(@"\SystemRoot\", StringComparison.OrdinalIgnoreCase)) exe = Win + exe[12..];
            if (exe.StartsWith(@"system32\", StringComparison.OrdinalIgnoreCase)) exe = Win + exe;
            if (!System.IO.Path.IsPathRooted(exe))
            {
                string sys = System.IO.Path.Combine(Win, "System32", exe);
                if (File.Exists(sys)) exe = sys;
                else if (File.Exists(sys + ".exe")) exe = sys + ".exe";
            }
            return exe;
        }
    }
}
