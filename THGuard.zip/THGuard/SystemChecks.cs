using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Management;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace THGuard
{
    public class DefenderStatus
    {
        public bool Available;
        public bool RealTime, AntivirusEnabled, TamperProtected;
        public int SignatureAgeDays = -1;
        public DateTime? SignatureUpdated, QuickScan, FullScan;
        public bool Pua;
        public List<string> ExcludedPaths = new(), ExcludedProcesses = new(), ExcludedExtensions = new();
        public List<string> OtherAntivirus = new();
    }

    public static class SystemChecks
    {
        public static string HostsPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"drivers\etc\hosts");

        static readonly string[] SensitiveDomains =
        {
            "microsoft", "windowsupdate", "windows.com", "live.com", "google", "virustotal", "kaspersky", "malwarebytes",
            "eset", "avast", "avg", "bitdefender", "norton", "mcafee", "sophos", "trendmicro", "avira", "bank", "banco",
            "itau", "bradesco", "santander", "caixa", "nubank", "paypal", "mercadopago", "steam", "discord", "facebook", "instagram"
        };

        // -------------------------------------------------------------- Defender

        public static DefenderStatus Defender()
        {
            var d = new DefenderStatus();
            try
            {
                var scope = new ManagementScope(@"\\.\root\Microsoft\Windows\Defender");
                using (var s = new ManagementObjectSearcher(scope, new ObjectQuery("SELECT * FROM MSFT_MpComputerStatus")))
                    foreach (ManagementObject mo in s.Get())
                        using (mo)
                        {
                            d.Available = true;
                            d.RealTime = mo["RealTimeProtectionEnabled"] is bool rt && rt;
                            d.AntivirusEnabled = mo["AntivirusEnabled"] is bool av && av;
                            d.TamperProtected = mo["IsTamperProtected"] is bool tp && tp;
                            d.SignatureAgeDays = mo["AntivirusSignatureAge"] is uint age ? (int)age : -1;
                            d.SignatureUpdated = Date(mo["AntivirusSignatureLastUpdated"]);
                            d.QuickScan = Date(mo["QuickScanEndTime"]);
                            d.FullScan = Date(mo["FullScanEndTime"]);
                        }

                using (var s = new ManagementObjectSearcher(scope, new ObjectQuery("SELECT * FROM MSFT_MpPreference")))
                    foreach (ManagementObject mo in s.Get())
                        using (mo)
                        {
                            d.ExcludedPaths = Arr(mo["ExclusionPath"]);
                            d.ExcludedProcesses = Arr(mo["ExclusionProcess"]);
                            d.ExcludedExtensions = Arr(mo["ExclusionExtension"]);
                            d.Pua = mo["PUAProtection"] is byte pua && pua == 1;
                        }
            }
            catch { }

            try
            {
                var scope = new ManagementScope(@"\\.\root\SecurityCenter2");
                using var s = new ManagementObjectSearcher(scope, new ObjectQuery("SELECT displayName FROM AntiVirusProduct"));
                foreach (ManagementObject mo in s.Get())
                    using (mo)
                    {
                        string n = mo["displayName"]?.ToString() ?? "";
                        if (n.Length > 0 && !n.Contains("Defender", StringComparison.OrdinalIgnoreCase)) d.OtherAntivirus.Add(n);
                    }
            }
            catch { }
            return d;
        }

        static DateTime? Date(object? v)
        {
            try
            {
                if (v is string s && s.Length > 0)
                {
                    var dt = ManagementDateTimeConverter.ToDateTime(s);
                    return dt.Year > 2000 ? dt : null;
                }
            }
            catch { }
            return null;
        }

        static List<string> Arr(object? v) => v is string[] a ? a.Where(x => !string.IsNullOrWhiteSpace(x) && !x.StartsWith("N/A")).ToList() : new();

        public static List<ThreatRecord> ThreatHistory()
        {
            var list = new List<ThreatRecord>();
            try
            {
                var scope = new ManagementScope(@"\\.\root\Microsoft\Windows\Defender");
                var names = new Dictionary<long, (string Name, int Sev)>();
                using (var s = new ManagementObjectSearcher(scope, new ObjectQuery("SELECT ThreatID, ThreatName, SeverityID FROM MSFT_MpThreat")))
                    foreach (ManagementObject mo in s.Get())
                        using (mo)
                            names[Convert.ToInt64(mo["ThreatID"])] = (mo["ThreatName"]?.ToString() ?? "", Convert.ToInt32(mo["SeverityID"] ?? 0));

                using (var s = new ManagementObjectSearcher(scope, new ObjectQuery("SELECT * FROM MSFT_MpThreatDetection")))
                    foreach (ManagementObject mo in s.Get())
                        using (mo)
                        {
                            long id = Convert.ToInt64(mo["ThreatID"]);
                            var (name, sev) = names.TryGetValue(id, out var n) ? n : ($"Ameaça {id}", 0);
                            var res = mo["Resources"] is string[] r ? string.Join("\n", r.Select(x => Regex.Replace(x, @"^\w+:_", ""))) : "";
                            int status = Convert.ToInt32(mo["ThreatStatusID"] ?? 0);
                            list.Add(new ThreatRecord
                            {
                                Name = name,
                                Resource = res,
                                Date = Date(mo["InitialDetectionTime"]) ?? DateTime.MinValue,
                                Severity = sev switch { 5 => "Grave", 4 => "Alta", 2 => "Média", 1 => "Baixa", _ => "Desconhecida" },
                                Status = status switch
                                {
                                    1 => "Detectada", 2 => "Limpa", 3 => "Em quarentena", 4 => "Removida", 5 => "Permitida",
                                    6 => "Bloqueada", 102 => "Falha ao limpar", 103 => "Falha na quarentena", 104 => "Falha ao remover",
                                    105 => "Falha ao permitir", 106 => "Abandonada", 107 => "Falha ao bloquear", _ => "Status " + status
                                }
                            });
                        }
            }
            catch { }
            return list.OrderByDescending(t => t.Date).ToList();
        }

        // ---------------------------------------------------------- verificações

        public static List<CheckItem> Checks(DefenderStatus d, out List<Finding> findings)
        {
            var items = new List<CheckItem>();
            findings = new List<Finding>();
            var f = findings;
            void Add(CheckItem c, Severity sev, string detail)
            {
                items.Add(c);
                if (!c.Ok) f.Add(new Finding
                {
                    Severity = sev, Category = "Sistema", Title = c.Name + ": " + c.Value, Detail = detail,
                    Key = "sys:" + c.Name, Fix = c.Fix, FixLabel = c.FixLabel
                });
            }

            bool otherAv = d.OtherAntivirus.Count > 0;
            if (!d.Available && !otherAv)
                Add(new CheckItem { Name = "Antivírus", Description = "O Microsoft Defender não respondeu", Value = "Indisponível", Ok = false },
                    Severity.High, "Não foi possível ler o Microsoft Defender e nenhum outro antivírus foi encontrado.");
            if (otherAv)
                items.Add(new CheckItem { Name = "Antivírus", Description = "Antivírus ativo no Windows", Value = string.Join(", ", d.OtherAntivirus), Ok = true });

            if (d.Available)
            {
                Add(new CheckItem
                {
                    Name = "Proteção em tempo real", Description = "Bloqueia vírus no momento em que aparecem",
                    Value = d.RealTime ? "Ligada" : otherAv ? "Desligada (outro antivírus ativo)" : "Desligada",
                    Ok = d.RealTime || otherAv, Fix = FixKind.EnableRealtime, FixLabel = "Ligar"
                }, Severity.High, "A proteção em tempo real do Defender está desligada. Malware costuma desligá-la.");

                bool fresh = d.SignatureAgeDays >= 0 && d.SignatureAgeDays <= 3;
                Add(new CheckItem
                {
                    Name = "Definições de vírus", Description = "Lista de vírus conhecidos do Defender",
                    Value = d.SignatureUpdated.HasValue ? $"Atualizadas em {d.SignatureUpdated:dd/MM/yyyy}" : "Desconhecido",
                    Ok = fresh || otherAv, Fix = FixKind.UpdateSignatures, FixLabel = "Atualizar"
                }, Severity.Medium, "As definições de vírus estão desatualizadas; ameaças novas podem passar.");

                Add(new CheckItem
                {
                    Name = "Bloqueio de apps indesejados (PUA)", Description = "Bloqueia adware, mineradores e programas que vêm escondidos em instaladores",
                    Value = d.Pua ? "Ligado" : "Desligado", Ok = d.Pua || otherAv, Fix = FixKind.EnablePua, FixLabel = "Ligar"
                }, Severity.Low, "A proteção contra aplicativos potencialmente indesejados (PUA) está desligada.");

                items.Add(new CheckItem
                {
                    Name = "Proteção contra adulteração", Description = "Impede que programas desliguem o Defender",
                    Value = d.TamperProtected ? "Ligada" : "Desligada (ligue em Segurança do Windows)", Ok = d.TamperProtected || otherAv
                });

                foreach (var p in d.ExcludedPaths) AddExclusion(f, items, "Pasta", p);
                foreach (var p in d.ExcludedProcesses) AddExclusion(f, items, "Processo", p);
                foreach (var p in d.ExcludedExtensions) AddExclusion(f, items, "Extensão", p);
            }

            // Firewall
            var fw = FirewallProfiles();
            Add(new CheckItem
            {
                Name = "Firewall do Windows", Description = "Bloqueia conexões não autorizadas",
                Value = fw.All(x => x.On) ? "Ligado" : "Desligado em: " + string.Join(", ", fw.Where(x => !x.On).Select(x => x.Name)),
                Ok = fw.All(x => x.On), Fix = FixKind.EnableFirewall, FixLabel = "Ligar"
            }, Severity.Medium, "O Firewall do Windows está desligado em pelo menos uma rede.");

            // UAC
            bool uac = RegInt(Registry.LocalMachine, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", "EnableLUA", 1) == 1;
            Add(new CheckItem
            {
                Name = "Controle de Conta de Usuário (UAC)", Description = "Pede permissão antes de um programa mexer no sistema",
                Value = uac ? "Ligado" : "Desligado", Ok = uac, Fix = FixKind.EnableUac, FixLabel = "Ligar"
            }, Severity.Medium, "O UAC está desligado: qualquer programa ganha acesso de administrador sem pedir.");

            // SmartScreen
            bool ssPolicyOff = RegInt(Registry.LocalMachine, @"SOFTWARE\Policies\Microsoft\Windows\System", "EnableSmartScreen", 1) == 0;
            string ss = RegStr(Registry.LocalMachine, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", "SmartScreenEnabled");
            bool smart = !ssPolicyOff && !ss.Equals("Off", StringComparison.OrdinalIgnoreCase);
            Add(new CheckItem
            {
                Name = "SmartScreen", Description = "Avisa antes de abrir programas baixados desconhecidos",
                Value = smart ? "Ligado" : "Desligado", Ok = smart, Fix = FixKind.EnableSmartScreen, FixLabel = "Ligar"
            }, Severity.Low, "O SmartScreen está desligado.");

            // Proxy
            const string inet = @"Software\Microsoft\Windows\CurrentVersion\Internet Settings";
            bool proxyOn = RegInt(Registry.CurrentUser, inet, "ProxyEnable", 0) == 1;
            string proxy = RegStr(Registry.CurrentUser, inet, "ProxyServer");
            string pac = RegStr(Registry.CurrentUser, inet, "AutoConfigURL");
            bool proxyOk = !proxyOn && pac.Length == 0;
            Add(new CheckItem
            {
                Name = "Proxy da internet", Description = "Malware usa proxy para espionar ou alterar o que você acessa",
                Value = proxyOk ? "Nenhum" : (pac.Length > 0 ? "Script: " + pac : "Ativo: " + proxy),
                Ok = proxyOk, Fix = FixKind.DisableProxy, FixLabel = "Desativar"
            }, Severity.Medium, "Há um proxy configurado. Se você não configurou isso (VPN, empresa), pode ser malware desviando sua internet.");

            // Hosts
            var bad = SuspiciousHostsLines();
            Add(new CheckItem
            {
                Name = "Arquivo hosts", Description = "Pode redirecionar sites (bancos, antivírus) para servidores falsos",
                Value = bad.Count == 0 ? "Normal" : $"{bad.Count} redirecionamento(s) suspeito(s)",
                Ok = bad.Count == 0, Fix = FixKind.CleanHosts, FixLabel = "Limpar (com backup)"
            }, Severity.High, "O arquivo hosts redireciona sites importantes:\n" + string.Join("\n", bad.Take(8)));

            return items;
        }

        static void AddExclusion(List<Finding> f, List<CheckItem> items, string kind, string value)
        {
            string v = value.ToLowerInvariant().TrimEnd('\\');
            bool dangerous = v is "c:" or ".exe" or "exe" or ".dll" or "dll" or ".ps1" or ".bat" or ".vbs"
                             || v.EndsWith(@"\appdata") || v.EndsWith(@"\temp") || v.Contains(@"\appdata\local\temp") || v == @"c:\users"
                             || v.EndsWith(@"\downloads") || v == @"c:\windows" || v.Contains("programdata") && v.Count(c => c == '\\') <= 1
                             || Rules.IsMinerName(v);
            items.Add(new CheckItem
            {
                Name = $"Exclusão do Defender ({kind})", Description = "O Defender não verifica este item",
                Value = value, Ok = false, Fix = FixKind.RemoveExclusion, FixLabel = "Remover"
            });
            f.Add(new Finding
            {
                Severity = dangerous ? Severity.High : Severity.Medium,
                Category = "Sistema",
                Title = $"Exclusão no antivírus: {value}",
                Detail = (dangerous ? "Exclusão muito ampla ou típica de malware: tudo aqui fica invisível para o antivírus. "
                                    : "O Defender ignora este item. Se você não adicionou essa exclusão, um programa pode ter adicionado para se esconder. ")
                         + $"Tipo: {kind}.",
                Key = $"excl:{kind}:{v}",
                Fix = FixKind.RemoveExclusion,
                FixLabel = "Remover exclusão",
                Tag = (kind, value)
            });
        }

        public static List<string> SuspiciousHostsLines()
        {
            var bad = new List<string>();
            try
            {
                foreach (var raw in File.ReadAllLines(HostsPath))
                {
                    string line = raw.Split('#')[0].Trim();
                    if (line.Length == 0) continue;
                    var parts = line.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length < 2) continue;
                    string ip = parts[0];
                    bool blockIp = ip is "0.0.0.0" or "127.0.0.1" or "::1" or "::";
                    foreach (var host in parts.Skip(1))
                    {
                        string h = host.ToLowerInvariant();
                        if (h is "localhost" or "localhost.localdomain") continue;
                        bool sensitive = SensitiveDomains.Any(s => h.Contains(s));
                        // Bloquear antivírus/Windows Update em 127.0.0.1 também é típico de malware
                        if (sensitive && (!blockIp || h.Contains("virustotal") || h.Contains("windowsupdate") || h.Contains("malwarebytes")
                                          || h.Contains("kaspersky") || h.Contains("eset") || h.Contains("avast") || h.Contains("bitdefender")))
                            bad.Add($"{ip} {host}");
                    }
                }
            }
            catch { }
            return bad;
        }

        static List<(string Name, bool On)> FirewallProfiles()
        {
            const string root = @"SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\";
            return new List<(string, bool)>
            {
                ("Domínio", RegInt(Registry.LocalMachine, root + "DomainProfile", "EnableFirewall", 1) == 1),
                ("Privada", RegInt(Registry.LocalMachine, root + "StandardProfile", "EnableFirewall", 1) == 1),
                ("Pública", RegInt(Registry.LocalMachine, root + "PublicProfile", "EnableFirewall", 1) == 1),
            };
        }

        static int RegInt(RegistryKey hive, string path, string name, int def)
        {
            try { using var k = hive.OpenSubKey(path); return k?.GetValue(name) is int v ? v : def; } catch { return def; }
        }

        static string RegStr(RegistryKey hive, string path, string name)
        {
            try { using var k = hive.OpenSubKey(path); return k?.GetValue(name)?.ToString() ?? ""; } catch { return ""; }
        }

        // ------------------------------------------------------------ extensões

        public static List<Finding> BrowserExtensions()
        {
            var findings = new List<Finding>();
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var browsers = new (string Name, string Dir, string Store)[]
            {
                ("Chrome", Path.Combine(local, @"Google\Chrome\User Data"), "clients2.google.com"),
                ("Edge", Path.Combine(local, @"Microsoft\Edge\User Data"), "edge.microsoft.com"),
                ("Brave", Path.Combine(local, @"BraveSoftware\Brave-Browser\User Data"), "clients2.google.com"),
            };

            foreach (var (browser, dir, store) in browsers)
            {
                if (!Directory.Exists(dir)) continue;
                IEnumerable<string> profiles;
                try { profiles = Directory.GetDirectories(dir).Where(d => Path.GetFileName(d) == "Default" || Path.GetFileName(d).StartsWith("Profile ")); }
                catch { continue; }

                foreach (var prof in profiles)
                {
                    string extDir = Path.Combine(prof, "Extensions");
                    if (!Directory.Exists(extDir)) continue;
                    foreach (var idDir in Directory.GetDirectories(extDir))
                    {
                        try
                        {
                            var ver = Directory.GetDirectories(idDir).OrderByDescending(x => x).FirstOrDefault();
                            if (ver == null) continue;
                            string manifest = Path.Combine(ver, "manifest.json");
                            if (!File.Exists(manifest)) continue;
                            using var doc = JsonDocument.Parse(File.ReadAllText(manifest), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
                            var root = doc.RootElement;
                            string name = ResolveName(root, ver);
                            string update = root.TryGetProperty("update_url", out var u) ? u.GetString() ?? "" : "";
                            var perms = new List<string>();
                            foreach (var key in new[] { "permissions", "host_permissions", "optional_permissions" })
                                if (root.TryGetProperty(key, out var arr) && arr.ValueKind == JsonValueKind.Array)
                                    perms.AddRange(arr.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String).Select(x => x.GetString() ?? ""));

                            bool allSites = perms.Any(p => p is "<all_urls>" or "*://*/*" or "http://*/*" or "https://*/*");
                            bool powerful = perms.Any(p => p is "webRequest" or "webRequestBlocking" or "proxy" or "debugger" or "nativeMessaging" or "management" or "declarativeNetRequest");
                            bool offStore = update.Length > 0 && !update.Contains(store) && !update.Contains("google.com") && !update.Contains("microsoft.com");

                            Severity sev = Severity.Info;
                            var why = new List<string>();
                            if (offStore) { sev = Severity.Medium; why.Add("instalada fora da loja oficial"); }
                            if (allSites && powerful) { if (sev < Severity.Low) sev = Severity.Low; why.Add("pode ler e alterar todos os sites que você visita"); }
                            if (sev == Severity.Info) continue;

                            findings.Add(new Finding
                            {
                                Severity = sev,
                                Category = "Extensão",
                                Title = $"{browser}: {name}",
                                Detail = ProcessScanner.Capitalize(string.Join("; ", why)) + ". Se você não reconhece essa extensão, remova pelo navegador.",
                                Path = ver,
                                Key = $"ext:{browser}:{Path.GetFileName(idDir)}"
                            });
                        }
                        catch { }
                    }
                }
            }

            // Extensões forçadas por política (adware faz isso)
            foreach (var (pol, label) in new[] { (@"SOFTWARE\Policies\Google\Chrome\ExtensionInstallForcelist", "Chrome"),
                                                 (@"SOFTWARE\Policies\Microsoft\Edge\ExtensionInstallForcelist", "Edge") })
            {
                try
                {
                    using var k = Registry.LocalMachine.OpenSubKey(pol);
                    if (k == null) continue;
                    foreach (var v in k.GetValueNames())
                        findings.Add(new Finding
                        {
                            Severity = Severity.Medium,
                            Category = "Extensão",
                            Title = $"{label}: extensão instalada à força por política",
                            Detail = $"Uma regra do sistema obriga o navegador a instalar: {k.GetValue(v)}. Adware usa isso para impedir a remoção. Se não for do seu trabalho/escola, desconfie.",
                            Key = $"extpol:{label}:{k.GetValue(v)}"
                        });
                }
                catch { }
            }
            return findings;
        }

        static string ResolveName(JsonElement root, string dir)
        {
            string name = root.TryGetProperty("name", out var n) ? n.GetString() ?? "" : "";
            if (!name.StartsWith("__MSG_")) return name;
            string key = name[6..^2];
            string def = root.TryGetProperty("default_locale", out var dl) ? dl.GetString() ?? "en" : "en";
            foreach (var loc in new[] { "pt_BR", "pt_PT", def, "en" })
            {
                try
                {
                    string file = Path.Combine(dir, "_locales", loc, "messages.json");
                    if (!File.Exists(file)) continue;
                    using var doc = JsonDocument.Parse(File.ReadAllText(file), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
                    foreach (var prop in doc.RootElement.EnumerateObject())
                        if (prop.Name.Equals(key, StringComparison.OrdinalIgnoreCase) && prop.Value.TryGetProperty("message", out var msg))
                            return msg.GetString() ?? name;
                }
                catch { }
            }
            return key;
        }
    }
}
