using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using WF = System.Windows.Forms;

namespace THGuard
{
    public partial class MainWindow : Window
    {
        readonly Settings _s;
        readonly bool _startHidden;
        readonly ObservableCollection<Finding> _findings = new();
        readonly ObservableCollection<ProcRow> _procs = new();
        readonly Dictionary<int, ProcRow> _procById = new();
        readonly Dictionary<int, ProcSnap> _snapCache = new();
        readonly ObservableCollection<StartupEntry> _startup = new();
        readonly HashSet<string> _alerted = new(StringComparer.OrdinalIgnoreCase);
        readonly UsageSampler _sampler = new();
        readonly DispatcherTimer _monitor = new() { Interval = TimeSpan.FromSeconds(3) };
        readonly ICollectionView _findingView, _procView, _startupView;

        DefenderStatus _def = new();
        List<CheckItem> _checks = new();
        List<Finding> _sysFindings = new();
        CancellationTokenSource? _scanCts;
        WF.NotifyIcon _tray = null!;
        bool _loading = true, _exiting, _monBusy, _scanning, _startupLoaded;

        public MainWindow(Settings settings, bool startHidden)
        {
            InitializeComponent();
            _s = settings;
            _startHidden = startHidden;
            Icon = System.Windows.Media.Imaging.BitmapFrame.Create(new Uri("pack://application:,,,/Assets/app.ico"));

            string version = typeof(MainWindow).Assembly.GetName().Version?.ToString(3) ?? "1.0.0";
            TxtVersion.Text = "v" + version;
            TxtAbout.Text = $"Versão {version} · Verificação de vírus, programas suspeitos e mineradores para Windows.";

            _findingView = CollectionViewSource.GetDefaultView(_findings);
            _findingView.Filter = o => o is Finding f && (ChkShowLow.IsChecked == true || f.Severity >= Severity.Medium);
            LstFindings.ItemsSource = _findingView;

            var pv = (ListCollectionView)CollectionViewSource.GetDefaultView(_procs);
            pv.SortDescriptions.Add(new SortDescription(nameof(ProcRow.Risk), ListSortDirection.Descending));
            pv.SortDescriptions.Add(new SortDescription(nameof(ProcRow.Cpu), ListSortDirection.Descending));
            pv.IsLiveSorting = true;
            pv.LiveSortingProperties.Add(nameof(ProcRow.Risk));
            pv.LiveSortingProperties.Add(nameof(ProcRow.Cpu));
            pv.IsLiveFiltering = true;
            pv.LiveFilteringProperties.Add(nameof(ProcRow.Risk));
            pv.Filter = o => o is ProcRow r && ProcMatches(r);
            _procView = pv;
            LstProc.ItemsSource = _procView;

            _startupView = CollectionViewSource.GetDefaultView(_startup);
            _startupView.Filter = o => o is StartupEntry e && StartMatches(e);
            LstStartup.ItemsSource = _startupView;

            SetupTray();
            BuildSwatches();
            LoadSettingsUi();
            HookSettings();

            StateChanged += (_, _) =>
            {
                Root.Margin = WindowState == WindowState.Maximized ? new Thickness(7) : new Thickness(0);
                BtnMax.Content = WindowState == WindowState.Maximized ? "" : "";
            };
            _monitor.Tick += async (_, _) => await MonitorTickAsync();
            Loaded += async (_, _) => await StartAsync();
            _loading = false;
        }

        void Status(string t) => TxtStatus.Text = t;
        void ShowBusy(string t) { TxtBusy.Text = t; BusyOverlay.Visibility = Visibility.Visible; }
        void HideBusy() => BusyOverlay.Visibility = Visibility.Collapsed;
        bool Confirm(string t) => MessageBox.Show(this, t, "TH Guard", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;

        async Task StartAsync()
        {
            if (_startHidden) Hide();
            _monitor.Start();
            await RefreshSystemAsync();
            RefreshQuarantine();
            await MonitorTickAsync();
        }

        // =====================================================================
        //  Navegação e janela
        // =====================================================================

        void Nav_Checked(object sender, RoutedEventArgs e)
        {
            if (PageHome == null) return;
            PageHome.Visibility = sender == NavHome ? Visibility.Visible : Visibility.Collapsed;
            PageScan.Visibility = sender == NavScan ? Visibility.Visible : Visibility.Collapsed;
            PageProc.Visibility = sender == NavProc ? Visibility.Visible : Visibility.Collapsed;
            PageStartup.Visibility = sender == NavStartup ? Visibility.Visible : Visibility.Collapsed;
            PageSystem.Visibility = sender == NavSystem ? Visibility.Visible : Visibility.Collapsed;
            PageQuar.Visibility = sender == NavQuar ? Visibility.Visible : Visibility.Collapsed;
            PageHistory.Visibility = sender == NavHistory ? Visibility.Visible : Visibility.Collapsed;
            PageSettings.Visibility = sender == NavSettings ? Visibility.Visible : Visibility.Collapsed;

            if (sender == NavStartup && !_startupLoaded) _ = LoadStartupAsync();
            if (sender == NavQuar) RefreshQuarantine();
            if (sender == NavHistory) _ = LoadHistoryAsync();
            if (sender == NavSettings) TxtTrustedCount.Text = $"{_s.Trusted.Count} alertas marcados como confiáveis";
        }

        void GoProc_Click(object sender, RoutedEventArgs e) => NavProc.IsChecked = true;
        void GoSystem_Click(object sender, RoutedEventArgs e) => NavSystem.IsChecked = true;

        void Min_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        void Max_Click(object sender, RoutedEventArgs e) =>
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        void Close_Click(object sender, RoutedEventArgs e) { if (_s.CloseToTray) HideToTray(); else ExitApp(); }

        protected override void OnClosing(CancelEventArgs e)
        {
            if (!_exiting) { e.Cancel = true; if (_s.CloseToTray) HideToTray(); else ExitApp(); }
            base.OnClosing(e);
        }

        void HideToTray()
        {
            Hide();
            if (!_s.TrayHintShown)
            {
                _s.TrayHintShown = true;
                _s.Save();
                _tray.ShowBalloonTip(3000, "TH Guard", "Continua na bandeja vigiando mineradores e processos suspeitos.", WF.ToolTipIcon.Info);
            }
        }

        void ShowFromTray()
        {
            Show();
            WindowState = WindowState.Normal;
            Activate();
        }

        void ExitApp()
        {
            _exiting = true;
            _monitor.Stop();
            _scanCts?.Cancel();
            _sampler.Dispose();
            _s.Save();
            _tray.Visible = false;
            _tray.Dispose();
            Application.Current.Shutdown();
        }

        void SetupTray()
        {
            var menu = new WF.ContextMenuStrip();
            menu.Items.Add("Abrir", null, (_, _) => ShowFromTray());
            menu.Items.Add("Verificação inteligente", null, (_, _) =>
            {
                ShowFromTray();
                NavScan.IsChecked = true;
                ScanSmart.IsChecked = true;
                StartScan_Click(this, new RoutedEventArgs());
            });
            menu.Items.Add(new WF.ToolStripSeparator());
            menu.Items.Add("Sair", null, (_, _) => ExitApp());

            using var s = Application.GetResourceStream(new Uri("pack://application:,,,/Assets/app.ico")).Stream;
            _tray = new WF.NotifyIcon { Icon = new System.Drawing.Icon(s, 32, 32), Visible = true, Text = "TH Guard", ContextMenuStrip = menu };
            _tray.DoubleClick += (_, _) => ShowFromTray();
            _tray.BalloonTipClicked += (_, _) => { ShowFromTray(); NavProc.IsChecked = true; };
        }

        // =====================================================================
        //  Visão geral
        // =====================================================================

        void RefreshHome()
        {
            bool otherAv = _def.OtherAntivirus.Count > 0;
            TxtAvName.Text = otherAv ? string.Join(", ", _def.OtherAntivirus) : _def.Available ? "Microsoft Defender" : "Nenhum antivírus encontrado";
            TxtAvRealtime.Text = _def.Available ? "Proteção em tempo real: " + (_def.RealTime ? "ligada" : "DESLIGADA") : "";
            TxtAvSigs.Text = _def.SignatureUpdated.HasValue ? $"Definições de {_def.SignatureUpdated:dd/MM/yyyy}" : "";
            var last = new[] { _def.QuickScan, _def.FullScan }.Where(x => x.HasValue).Max();
            TxtAvLastScan.Text = last.HasValue ? $"Última verificação do Defender: {last:dd/MM/yyyy}" : "";

            int high = _findings.Count(f => f.Severity == Severity.High && !f.Done) + _sysFindings.Count(f => f.Severity == Severity.High && !_s.Trusted.Contains(f.Key));
            int med = _findings.Count(f => f.Severity == Severity.Medium && !f.Done) + _sysFindings.Count(f => f.Severity == Severity.Medium && !_s.Trusted.Contains(f.Key));
            int procRisk = _procs.Count(p => p.Risk >= Severity.High);

            if (high > 0 || procRisk > 0)
            {
                ShieldBg.Background = Sev.HighBrush;
                ShieldIcon.Text = "";
                TxtHomeTitle.Text = "Atenção: encontramos problemas";
                TxtHomeSub.Text = $"{high + procRisk} alerta(s) de risco alto. Abra Verificar para ver os detalhes e corrigir.";
            }
            else if (med > 0)
            {
                ShieldBg.Background = Sev.MediumBrush;
                ShieldIcon.Text = "";
                TxtHomeTitle.Text = "Alguns itens merecem atenção";
                TxtHomeSub.Text = $"{med} alerta(s) de risco médio. Nada crítico, mas vale revisar.";
            }
            else
            {
                ShieldBg.Background = Sev.OkBrush;
                ShieldIcon.Text = "";
                TxtHomeTitle.Text = "Seu PC parece seguro";
                TxtHomeSub.Text = _s.LastSmartScan == default
                    ? "Faça uma verificação inteligente para checar mineradores, inicialização e configurações."
                    : "Nenhum problema importante encontrado na última verificação e no monitor em tempo real.";
            }
            TxtLastScan.Text = _s.LastSmartScan == default ? "Nunca verificado" : $"Última: {_s.LastSmartScan:dd/MM HH:mm}";
            TxtLastCounts.Text = _findings.Count == 0 && _s.LastSmartScan == default
                ? "Nenhuma verificação ainda"
                : $"{_findings.Count(f => f.Severity == Severity.High)} altos · {_findings.Count(f => f.Severity == Severity.Medium)} médios · {_findings.Count(f => f.Severity == Severity.Low)} baixos";
            TxtSysIssues.Text = $"{_checks.Count(c => !c.Ok)} configuração(ões) de segurança para revisar";
        }

        async void HomeSmart_Click(object sender, RoutedEventArgs e)
        {
            NavScan.IsChecked = true;
            ScanSmart.IsChecked = true;
            await RunScanAsync("smart", null);
        }

        async void UpdateSigs_Click(object sender, RoutedEventArgs e)
        {
            ShowBusy("Atualizando definições de vírus...");
            var (code, _) = await Defender.UpdateAsync(null);
            HideBusy();
            Status(code == 0 ? "Definições atualizadas." : "Não foi possível atualizar agora.");
            await RefreshSystemAsync();
        }

        // =====================================================================
        //  Verificação
        // =====================================================================

        async void StartScan_Click(object sender, RoutedEventArgs e)
        {
            if (_scanning) return;
            if (ScanCustom.IsChecked == true)
            {
                var dlg = new OpenFolderDialog { Title = "Escolha a pasta para verificar" };
                if (dlg.ShowDialog(this) != true) return;
                await RunScanAsync("custom", dlg.FolderName);
            }
            else if (ScanQuick.IsChecked == true) await RunScanAsync("quick", null);
            else if (ScanFull.IsChecked == true)
            {
                if (!Confirm("A verificação completa do Defender pode levar mais de uma hora. Continuar?")) return;
                await RunScanAsync("full", null);
            }
            else await RunScanAsync("smart", null);
        }

        void CancelScan_Click(object sender, RoutedEventArgs e) => _scanCts?.Cancel();

        async Task RunScanAsync(string type, string? target)
        {
            if (_scanning) return;
            _scanning = true;
            _scanCts = new CancellationTokenSource();
            var ct = _scanCts.Token;
            BtnScan.IsEnabled = false;
            BtnScanCancel.Visibility = Visibility.Visible;
            PrgScan.Visibility = Visibility.Visible;
            ScanSummary.Visibility = Visibility.Collapsed;
            TxtNoFindings.Visibility = Visibility.Collapsed;
            _findings.Clear();
            var log = new Progress<string>(t => TxtScanLog.Text = t);
            var list = new List<Finding>();

            try
            {
                switch (type)
                {
                    case "smart":
                        TxtScanTitle.Text = "Verificação inteligente em andamento...";
                        list.AddRange(await ProcessScanner.ScanAsync(_s, log));
                        if (ct.IsCancellationRequested) break;

                        ((IProgress<string>)log).Report("Verificando o que inicia com o Windows...");
                        var entries = await StartupScanner.LoadAsync(_s.ScanSignaturesInStartup);
                        ReplaceStartup(entries);
                        list.AddRange(StartupScanner.ToFindings(entries));
                        if (ct.IsCancellationRequested) break;

                        ((IProgress<string>)log).Report("Verificando configurações de segurança...");
                        await RefreshSystemAsync();
                        list.AddRange(_sysFindings);

                        if (_s.ScanExtensions && !ct.IsCancellationRequested)
                        {
                            ((IProgress<string>)log).Report("Verificando extensões dos navegadores...");
                            list.AddRange(await Task.Run(() => SystemChecks.BrowserExtensions()));
                        }
                        if (_s.SmartIncludesDefenderQuick && !ct.IsCancellationRequested)
                        {
                            ((IProgress<string>)log).Report("Microsoft Defender: verificação rápida...");
                            var (_, o) = await Defender.QuickScanAsync(log, ct);
                            list.AddRange(Defender.ParseThreats(o));
                        }
                        if (!ct.IsCancellationRequested) { _s.LastSmartScan = DateTime.Now; _s.Save(); }
                        break;

                    case "quick":
                        TxtScanTitle.Text = "Microsoft Defender: verificação rápida...";
                        var q = await Defender.QuickScanAsync(log, ct);
                        list.AddRange(Defender.ParseThreats(q.Output));
                        break;

                    case "full":
                        TxtScanTitle.Text = "Microsoft Defender: verificação completa...";
                        var f = await Defender.FullScanAsync(log, ct);
                        list.AddRange(Defender.ParseThreats(f.Output));
                        break;

                    case "custom":
                        TxtScanTitle.Text = $"Verificando {target}...";
                        list.AddRange(await FileScanner.ScanAsync(target!, _s, log, ct));
                        break;
                }
            }
            catch (Exception ex) { ((IProgress<string>)log).Report("Erro: " + ex.Message); }

            var final = list.Where(x => !_s.Trusted.Contains(x.Key))
                            .GroupBy(x => x.Key)
                            .Select(g => g.OrderByDescending(x => x.Severity).First())
                            .OrderByDescending(x => x.Severity).ThenBy(x => x.Category).ThenBy(x => x.Title)
                            .ToList();
            foreach (var x in final) _findings.Add(x);

            int h = final.Count(x => x.Severity == Severity.High), m = final.Count(x => x.Severity == Severity.Medium), l = final.Count(x => x.Severity == Severity.Low);
            TxtCountHigh.Text = $"{h} ALTO";
            TxtCountMed.Text = $"{m} MÉDIO";
            TxtCountLow.Text = $"{l} BAIXO";
            ScanSummary.Visibility = Visibility.Visible;
            TxtScanTitle.Text = ct.IsCancellationRequested ? "Verificação cancelada"
                              : h + m == 0 ? "Nenhum problema importante encontrado"
                              : $"{h + m} problema(s) encontrado(s)";
            TxtNoFindings.Visibility = _findingView.IsEmpty ? Visibility.Visible : Visibility.Collapsed;
            TxtNoFindings.Text = l > 0 ? "Nenhum alerta alto ou médio. Marque \"Mostrar alertas baixos\" para ver o resto." : "Nenhum problema encontrado.";

            PrgScan.Visibility = Visibility.Collapsed;
            BtnScan.IsEnabled = true;
            BtnScanCancel.Visibility = Visibility.Collapsed;
            _scanning = false;
            RefreshHome();
            if (!IsVisible && h > 0)
                _tray.ShowBalloonTip(4000, "TH Guard", $"Verificação concluída: {h} alerta(s) de risco alto.", WF.ToolTipIcon.Warning);
        }

        void ShowLow_Changed(object sender, RoutedEventArgs e)
        {
            _findingView?.Refresh();
            if (TxtNoFindings != null && _findingView != null)
                TxtNoFindings.Visibility = _findingView.IsEmpty && _findings.Count >= 0 && ScanSummary.Visibility == Visibility.Visible ? Visibility.Visible : Visibility.Collapsed;
        }

        static Finding? Of(object sender) => (sender as FrameworkElement)?.DataContext as Finding;

        async void FindingFix_Click(object sender, RoutedEventArgs e)
        {
            if (Of(sender) is not Finding f) return;
            if (f.Fix is FixKind.Quarantine or FixKind.DisableStartup or FixKind.RemoveWmi or FixKind.KillProcess or FixKind.CleanHosts or FixKind.RemoveExclusion)
                if (!Confirm($"{f.FixLabel}?\n\n{f.Title}")) return;
            await ApplyFixAsync(f);
            RefreshHome();
        }

        async Task ApplyFixAsync(Finding f)
        {
            f.Status = "Aplicando...";
            var (ok, msg) = await Fixes.ApplyAsync(f);
            f.Status = msg;
            if (ok) f.Done = true;
            Status(msg);
            if (f.Category == "Sistema") await RefreshSystemAsync();
            RefreshQuarantine();
        }

        async void FixAllHigh_Click(object sender, RoutedEventArgs e)
        {
            var list = _findings.Where(f => f.Severity == Severity.High && f.HasFix).ToList();
            if (list.Count == 0) { Status("Nenhum alerta alto com correção automática."); return; }
            if (!Confirm($"Corrigir {list.Count} alerta(s) de risco alto?\n\n" + string.Join("\n", list.Take(15).Select(f => $"• {f.FixLabel}: {f.Title}"))
                         + "\n\nArquivos vão para a quarentena e podem ser restaurados.")) return;
            ShowBusy("Corrigindo...");
            foreach (var f in list) await ApplyFixAsync(f);
            HideBusy();
            RefreshHome();
        }

        void FindingOpen_Click(object sender, RoutedEventArgs e)
        {
            if (Of(sender) is Finding f) OpenLocation(f.Path);
        }

        async void FindingVt_Click(object sender, RoutedEventArgs e)
        {
            if (Of(sender) is Finding f) await OpenVirusTotalAsync(f.Path);
        }

        void FindingTrust_Click(object sender, RoutedEventArgs e)
        {
            if (Of(sender) is not Finding f) return;
            if (!Confirm($"Confiar em \"{f.Title}\"?\n\nEste alerta não vai aparecer mais. Dá para desfazer em Configurações.")) return;
            if (!_s.Trusted.Contains(f.Key)) _s.Trusted.Add(f.Key);
            _s.Save();
            _findings.Remove(f);
            RefreshHome();
        }

        static void OpenLocation(string path)
        {
            if (File.Exists(path)) Shell.Open("explorer.exe", $"/select,\"{path}\"");
            else if (Directory.Exists(path)) Shell.Open("explorer.exe", $"\"{path}\"");
        }

        async Task OpenVirusTotalAsync(string path)
        {
            if (!File.Exists(path)) { Status("Arquivo não encontrado."); return; }
            Status("Calculando o código (hash) do arquivo...");
            string hash = await Task.Run(() => Signatures.Sha256(path));
            if (hash.Length == 0) { Status("Não foi possível ler o arquivo."); return; }
            Shell.Open(VirusTotal.Link(hash));
            Status("Aberto no VirusTotal.");
        }

        // =====================================================================
        //  Monitor de processos e mineração
        // =====================================================================

        async Task MonitorTickAsync()
        {
            if (_monBusy) return;
            if (!IsVisible && !_s.MinerAlerts) return;
            _monBusy = true;
            try
            {
                List<ProcSnap>? snaps = null;
                List<Native.TcpConn> conns = new();
                HashSet<int> wins = new();
                var cache = _snapCache;
                await Task.Run(() =>
                {
                    _sampler.Sample();
                    if (_sampler.MemoryMB.Keys.Any(p => p > 4 && p != Environment.ProcessId && !cache.ContainsKey(p)))
                        snaps = ProcessScanner.Snapshot();
                    conns = Native.TcpConnections();
                    wins = Native.WindowPids();
                });

                if (snaps != null)
                {
                    foreach (var sn in snaps) _snapCache[sn.Pid] = sn;
                    var newPaths = snaps.Select(x => x.Path).Where(p => p.Length > 0 && Signatures.Cached(p) == null)
                                        .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                    if (newPaths.Count > 0) _ = Signatures.VerifyAsync(newPaths);
                }

                var alive = _sampler.MemoryMB.Keys.ToHashSet();
                foreach (var dead in _procById.Keys.Where(k => !alive.Contains(k)).ToList())
                {
                    _procs.Remove(_procById[dead]);
                    _procById.Remove(dead);
                    _snapCache.Remove(dead);
                }

                foreach (int pid in alive)
                {
                    if (!_snapCache.TryGetValue(pid, out var snap)) continue;
                    if (!_procById.TryGetValue(pid, out var row))
                    {
                        row = new ProcRow { Pid = pid, Name = snap.Name, Path = snap.Path, CommandLine = snap.CommandLine, ParentPid = snap.ParentPid };
                        _procById[pid] = row;
                        _procs.Add(row);
                    }
                    row.Cpu = _sampler.Cpu.GetValueOrDefault(pid);
                    row.Gpu = _sampler.Gpu.GetValueOrDefault(pid);
                    row.MemoryMB = _sampler.MemoryMB.GetValueOrDefault(pid);
                    row.HasWindow = wins.Contains(pid);
                    bool high = !row.HasWindow && (row.Cpu >= _s.MinerCpuThreshold || row.Gpu >= _s.MinerGpuThreshold);
                    row.HighUsageSamples = high ? row.HighUsageSamples + 1 : 0;

                    var sig = snap.Path.Length > 0 ? Signatures.Cached(snap.Path) : null;
                    row.Signer = sig?.Text ?? (snap.Path.Length > 0 ? "verificando assinatura..." : "sem acesso ao caminho");
                    var (risk, reasons) = ProcessScanner.Evaluate(snap, sig, row.Cpu, row.Gpu, row.HasWindow, conns, row.HighUsageSamples >= 10, _s);
                    string key = "proc:" + (snap.Path.Length > 0 ? snap.Path : snap.Name).ToLowerInvariant();
                    if (_s.Trusted.Contains(key)) { risk = Severity.Info; reasons.Clear(); }
                    row.Risk = risk;
                    row.Reasons = ProcessScanner.Capitalize(string.Join("; ", reasons));

                    if (risk == Severity.High && _s.MinerAlerts && _alerted.Add(key))
                        _tray.ShowBalloonTip(5000, "TH Guard: processo suspeito", $"{snap.Name}: {reasons.FirstOrDefault()}", WF.ToolTipIcon.Warning);
                }

                UpdateMinerSummary();
            }
            catch { }
            finally { _monBusy = false; }
        }

        void UpdateMinerSummary()
        {
            int sus = _procs.Count(p => p.Risk >= Severity.Medium);
            TxtMinerState.Text = sus == 0 ? "Nenhum processo suspeito agora" : $"{sus} processo(s) suspeito(s) em execução";
            TxtMinerState.Foreground = sus == 0 ? Sev.OkBrush : Sev.MediumBrush;
            var topCpu = _procs.OrderByDescending(p => p.Cpu).FirstOrDefault();
            var topGpu = _procs.Where(p => p.Gpu >= 1).OrderByDescending(p => p.Gpu).FirstOrDefault();
            TxtMinerTop.Text = (topCpu != null ? $"Mais CPU: {topCpu.Name} ({topCpu.Cpu:0}%)" : "")
                               + (topGpu != null ? $"\nMais GPU: {topGpu.Name} ({topGpu.Gpu:0}%)" : "");
            double idle = Native.IdleSeconds();
            string idleText = idle >= 60 ? $"PC sem uso há {idle / 60:0} min" : "Você está usando o PC agora";
            TxtIdle.Text = idleText + (idle >= 300 ? " (mineradores costumam acelerar nessa hora)" : "");
            TxtProcIdle.Text = idleText;
            if (PageHome.Visibility == Visibility.Visible) RefreshHome();
        }

        bool ProcMatches(ProcRow r)
        {
            if (ChkOnlySuspicious?.IsChecked == true && r.Risk < Severity.Low) return false;
            string q = TxtProcSearch?.Text.Trim() ?? "";
            return q.Length == 0 || r.Name.Contains(q, StringComparison.OrdinalIgnoreCase) || r.Path.Contains(q, StringComparison.OrdinalIgnoreCase);
        }

        void ProcSearch_Changed(object sender, TextChangedEventArgs e)
        {
            PhProcSearch.Visibility = TxtProcSearch.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
            _procView?.Refresh();
        }

        void ProcFilter_Changed(object sender, RoutedEventArgs e) => _procView?.Refresh();

        static ProcRow? RowOf(object sender) => (sender as FrameworkElement)?.DataContext as ProcRow;

        void ProcKill_Click(object sender, RoutedEventArgs e)
        {
            if (RowOf(sender) is not ProcRow r) return;
            if (!Confirm($"Encerrar {r.Name} (PID {r.Pid})?")) return;
            try { using var p = System.Diagnostics.Process.GetProcessById(r.Pid); p.Kill(true); Status($"{r.Name} encerrado."); }
            catch (Exception ex) { Status("Não foi possível: " + ex.Message); }
        }

        async void ProcQuarantine_Click(object sender, RoutedEventArgs e)
        {
            if (RowOf(sender) is not ProcRow r || r.Path.Length == 0) return;
            if (Signatures.Cached(r.Path)?.Microsoft == true || Rules.InWindows(r.Path)) { Status("Arquivos do Windows não vão para a quarentena."); return; }
            if (!Confirm($"Encerrar {r.Name} e colocar o arquivo em quarentena?\n\n{r.Path}")) return;
            var (ok, msg) = await Quarantine.QuarantineFileAsync(r.Path, $"Processo suspeito: {r.Reasons}");
            Status(msg);
            RefreshQuarantine();
        }

        void ProcOpen_Click(object sender, RoutedEventArgs e)
        {
            if (RowOf(sender) is ProcRow r) OpenLocation(r.Path);
        }

        // =====================================================================
        //  Inicialização
        // =====================================================================

        async Task LoadStartupAsync()
        {
            ShowBusy("Lendo tudo que inicia com o Windows e verificando assinaturas...");
            var list = await StartupScanner.LoadAsync(true);
            ReplaceStartup(list);
            HideBusy();
        }

        void ReplaceStartup(List<StartupEntry> list)
        {
            _startup.Clear();
            foreach (var e in list) _startup.Add(e);
            _startupLoaded = true;
        }

        bool StartMatches(StartupEntry e)
        {
            if (ChkStartSuspicious?.IsChecked == true && e.Risk < Severity.Low) return false;
            string q = TxtStartSearch?.Text.Trim() ?? "";
            return q.Length == 0 || e.Name.Contains(q, StringComparison.OrdinalIgnoreCase) || e.Command.Contains(q, StringComparison.OrdinalIgnoreCase)
                   || e.Source.Contains(q, StringComparison.OrdinalIgnoreCase);
        }

        void StartSearch_Changed(object sender, TextChangedEventArgs e)
        {
            PhStartSearch.Visibility = TxtStartSearch.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
            _startupView?.Refresh();
        }

        void StartFilter_Changed(object sender, RoutedEventArgs e) => _startupView?.Refresh();
        async void StartRefresh_Click(object sender, RoutedEventArgs e) => await LoadStartupAsync();

        static StartupEntry? EntryOf(object sender) => (sender as FrameworkElement)?.DataContext as StartupEntry;

        async void StartDisable_Click(object sender, RoutedEventArgs e)
        {
            if (EntryOf(sender) is not StartupEntry en) return;
            if (!en.CanDisable && en.Source != "WMI") { Status("Esse tipo de entrada não pode ser desativado aqui."); return; }
            if (!Confirm($"Desativar \"{en.Name}\"?\n\n{en.Command}\n\nPode ser restaurado na Quarentena.")) return;
            if (en.Source == "WMI")
            {
                var f = new Finding { Fix = FixKind.RemoveWmi, Tag = en };
                var r = await Fixes.ApplyAsync(f);
                Status(r.Message);
                if (r.Ok) en.Enabled = false;
                return;
            }
            var (ok, msg) = await Quarantine.DisableStartupAsync(en, $"Inicialização: {en.Name}");
            if (ok) en.Status = "Desativado";
            Status(msg);
            RefreshQuarantine();
        }

        void StartOpen_Click(object sender, RoutedEventArgs e)
        {
            if (EntryOf(sender) is StartupEntry en) OpenLocation(en.FilePath);
        }

        async void StartVt_Click(object sender, RoutedEventArgs e)
        {
            if (EntryOf(sender) is StartupEntry en) await OpenVirusTotalAsync(en.FilePath);
        }

        // =====================================================================
        //  Sistema
        // =====================================================================

        async Task RefreshSystemAsync()
        {
            _def = await Task.Run(() => SystemChecks.Defender());
            _checks = SystemChecks.Checks(_def, out var findings);
            _sysFindings = findings;
            ListChecks.ItemsSource = _checks;
            RefreshHome();
        }

        async void SystemRefresh_Click(object sender, RoutedEventArgs e)
        {
            ShowBusy("Verificando configurações...");
            await RefreshSystemAsync();
            HideBusy();
        }

        async void CheckFix_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is not CheckItem c) return;
            object? tag = null;
            if (c.Fix == FixKind.RemoveExclusion)
            {
                string kind = c.Name.Contains("Processo") ? "Processo" : c.Name.Contains("Extensão") ? "Extensão" : "Pasta";
                tag = (kind, c.Value);
                if (!Confirm($"Remover a exclusão \"{c.Value}\" do antivírus?")) return;
            }
            ShowBusy($"{c.FixLabel}: {c.Name}...");
            var (ok, msg) = await Fixes.ApplyAsync(new Finding { Fix = c.Fix, Tag = tag, Category = "Sistema" });
            HideBusy();
            Status(msg);
            await RefreshSystemAsync();
        }

        // =====================================================================
        //  Quarentena e histórico
        // =====================================================================

        void RefreshQuarantine()
        {
            var list = Quarantine.Load().OrderByDescending(q => q.Date).ToList();
            LstQuar.ItemsSource = list;
            TxtQuarEmpty.Visibility = list.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            TxtQuarCount.Text = $"{list.Count} item(ns) na quarentena";
        }

        async void QuarRestore_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is not QuarantineItem q) return;
            if (!Confirm($"Restaurar \"{q.Name}\"?\n\nSó faça isso se tiver certeza de que é seguro.")) return;
            var (ok, msg) = await Quarantine.RestoreAsync(q);
            Status(msg);
            RefreshQuarantine();
        }

        void QuarDelete_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is not QuarantineItem q) return;
            if (!Confirm($"Excluir \"{q.Name}\" de vez? Não poderá ser restaurado.")) return;
            Quarantine.Remove(q);
            RefreshQuarantine();
        }

        void QuarClear_Click(object sender, RoutedEventArgs e)
        {
            var list = Quarantine.Load();
            if (list.Count == 0) return;
            if (!Confirm($"Excluir os {list.Count} itens da quarentena de vez?")) return;
            foreach (var q in list) Quarantine.Remove(q);
            RefreshQuarantine();
        }

        async Task LoadHistoryAsync()
        {
            var list = await Task.Run(() => SystemChecks.ThreatHistory());
            LstHistory.ItemsSource = list;
            TxtHistEmpty.Visibility = list.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        void OpenSecurity_Click(object sender, RoutedEventArgs e) => Shell.Open("windowsdefender://threat");

        // =====================================================================
        //  Configurações
        // =====================================================================

        void LoadSettingsUi()
        {
            bool was = _loading;
            _loading = true;
            RbDark.IsChecked = _s.Theme == "dark";
            RbBlack.IsChecked = _s.Theme == "black";
            RbLight.IsChecked = _s.Theme == "light";
            TxtColorA.Text = _s.AccentA;
            TxtColorB.Text = _s.AccentB;
            ChkLogoAccent.IsChecked = _s.LogoUseAccent;
            TxtLogoP.Text = _s.LogoPrimary;
            TxtLogoS.Text = _s.LogoSecondary;
            ChkSmartDefender.IsChecked = _s.SmartIncludesDefenderQuick;
            ChkExtensions.IsChecked = _s.ScanExtensions;
            TxtVtKey.Text = _s.VirusTotalKey;
            ChkMinerAlerts.IsChecked = _s.MinerAlerts;
            SldCpuThr.Value = _s.MinerCpuThreshold;
            SldGpuThr.Value = _s.MinerGpuThreshold;
            ChkStartup.IsChecked = _s.StartWithWindows;
            ChkTray.IsChecked = _s.CloseToTray;
            UpdateLabels();
            RefreshColorUi();
            _loading = was;
        }

        void HookSettings()
        {
            foreach (var cb in new[] { ChkSmartDefender, ChkExtensions, ChkMinerAlerts, ChkTray })
            {
                cb.Checked += SettingChanged;
                cb.Unchecked += SettingChanged;
            }
            SldCpuThr.ValueChanged += (_, _) => SettingChanged(null, null);
            SldGpuThr.ValueChanged += (_, _) => SettingChanged(null, null);
            TxtVtKey.LostFocus += (_, _) => { _s.VirusTotalKey = TxtVtKey.Text.Trim(); _s.Save(); };
            ChkStartup.Checked += async (_, _) => await StartupChanged(true);
            ChkStartup.Unchecked += async (_, _) => await StartupChanged(false);

            foreach (var rb in new[] { RbDark, RbBlack, RbLight }) rb.Checked += Theme_Checked;
            ChkLogoAccent.Checked += (_, _) => CommitColors();
            ChkLogoAccent.Unchecked += (_, _) => CommitColors();
            foreach (var tb in new[] { TxtColorA, TxtColorB, TxtLogoP, TxtLogoS })
            {
                tb.LostFocus += (_, _) => CommitColors();
                tb.KeyDown += (_, e) => { if (e.Key == Key.Enter) CommitColors(); };
            }
            PrevA.MouseLeftButtonUp += (_, _) => PickColor(TxtColorA);
            PrevB.MouseLeftButtonUp += (_, _) => PickColor(TxtColorB);
            PrevLogoP.MouseLeftButtonUp += (_, _) => PickColor(TxtLogoP);
            PrevLogoS.MouseLeftButtonUp += (_, _) => PickColor(TxtLogoS);
        }

        void SettingChanged(object? sender, RoutedEventArgs? e)
        {
            UpdateLabels();
            if (_loading) return;
            _s.SmartIncludesDefenderQuick = ChkSmartDefender.IsChecked == true;
            _s.ScanExtensions = ChkExtensions.IsChecked == true;
            _s.MinerAlerts = ChkMinerAlerts.IsChecked == true;
            _s.MinerCpuThreshold = (int)SldCpuThr.Value;
            _s.MinerGpuThreshold = (int)SldGpuThr.Value;
            _s.CloseToTray = ChkTray.IsChecked == true;
            _s.Save();
        }

        async Task StartupChanged(bool on)
        {
            if (_loading) return;
            _s.StartWithWindows = on;
            _s.Save();
            await StartupManager.SetAsync(on);
            Status(on ? "O TH Guard vai iniciar com o Windows." : "Início automático desativado.");
        }

        void UpdateLabels()
        {
            LblCpuThr.Text = $"Suspeitar acima de {(int)SldCpuThr.Value}% de CPU";
            LblGpuThr.Text = $"Suspeitar acima de {(int)SldGpuThr.Value}% de placa de vídeo";
            TxtLogoP.IsEnabled = PrevLogoP.IsEnabled = ChkLogoAccent.IsChecked != true;
            TxtLogoP.Opacity = PrevLogoP.Opacity = ChkLogoAccent.IsChecked == true ? 0.4 : 1;
        }

        void ClearTrusted_Click(object sender, RoutedEventArgs e)
        {
            if (_s.Trusted.Count == 0) return;
            if (!Confirm($"Voltar a mostrar os {_s.Trusted.Count} alertas marcados como confiáveis?")) return;
            _s.Trusted.Clear();
            _s.Save();
            TxtTrustedCount.Text = "0 alertas marcados como confiáveis";
        }

        void VtSignup_Click(object sender, RoutedEventArgs e) => Shell.Open("https://www.virustotal.com/gui/my-apikey");
        void GitHub_Click(object sender, RoutedEventArgs e) => Shell.Open("https://github.com/Thiagosystems");

        void Theme_Checked(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            _s.Theme = sender == RbLight ? "light" : sender == RbBlack ? "black" : "dark";
            _s.Save();
            ThemeManager.Apply(_s);
            RefreshColorUi();
        }

        void BuildSwatches()
        {
            foreach (var p in ThemeManager.Presets)
            {
                var b = new Border
                {
                    Width = 26, Height = 26, CornerRadius = new CornerRadius(13), Margin = new Thickness(0, 0, 8, 8),
                    BorderThickness = new Thickness(2), Cursor = Cursors.Hand, ToolTip = p.Name, Tag = p,
                    Background = new LinearGradientBrush(ThemeManager.Parse(p.A, p.A), ThemeManager.Parse(p.B, p.B), new Point(0, 0), new Point(1, 1))
                };
                b.MouseLeftButtonUp += (_, _) => { TxtColorA.Text = p.A; TxtColorB.Text = p.B; CommitColors(); };
                Swatches.Children.Add(b);
            }
        }

        void CommitColors()
        {
            UpdateLabels();
            if (_loading) return;
            _s.AccentA = Valid(TxtColorA, _s.AccentA);
            _s.AccentB = Valid(TxtColorB, _s.AccentB);
            _s.LogoPrimary = Valid(TxtLogoP, _s.LogoPrimary);
            _s.LogoSecondary = Valid(TxtLogoS, _s.LogoSecondary);
            _s.LogoUseAccent = ChkLogoAccent.IsChecked == true;
            _s.Save();
            ThemeManager.Apply(_s);
            RefreshColorUi();
        }

        static string Valid(TextBox tb, string fallback)
        {
            string v = ThemeManager.TryParse(tb.Text, out var n) ? n : fallback;
            tb.Text = v;
            return v;
        }

        void PickColor(TextBox target)
        {
            var c = ThemeManager.Parse(target.Text, "#FFFFFF");
            using var dlg = new WF.ColorDialog { FullOpen = true, Color = System.Drawing.Color.FromArgb(c.R, c.G, c.B) };
            if (dlg.ShowDialog() != WF.DialogResult.OK) return;
            target.Text = $"#{dlg.Color.R:X2}{dlg.Color.G:X2}{dlg.Color.B:X2}";
            CommitColors();
        }

        void RefreshColorUi()
        {
            var ring = (Brush)FindResource("TextBrush");
            foreach (Border b in Swatches.Children)
            {
                var p = ((string Name, string A, string B))b.Tag;
                bool sel = string.Equals(p.A, _s.AccentA, StringComparison.OrdinalIgnoreCase) && string.Equals(p.B, _s.AccentB, StringComparison.OrdinalIgnoreCase);
                b.BorderBrush = sel ? ring : Brushes.Transparent;
            }
            PrevA.Background = Solid(_s.AccentA);
            PrevB.Background = Solid(_s.AccentB);
            PrevLogoP.Background = Solid(_s.LogoPrimary);
            PrevLogoS.Background = Solid(_s.LogoSecondary);
        }

        static SolidColorBrush Solid(string hex) => new(ThemeManager.Parse(hex, "#FFFFFF"));
    }
}
