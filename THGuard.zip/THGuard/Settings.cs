using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace THGuard
{
    public class Settings
    {
        // Aparência
        public string Theme { get; set; } = "dark";
        public string AccentA { get; set; } = "#22D3EE";
        public string AccentB { get; set; } = "#8B5CF6";
        public bool LogoUseAccent { get; set; } = false;
        public string LogoPrimary { get; set; } = "#E10600";
        public string LogoSecondary { get; set; } = "#E6E6E6";

        // Verificação
        public string VirusTotalKey { get; set; } = "";
        public bool SmartIncludesDefenderQuick { get; set; } = false;
        public bool ScanExtensions { get; set; } = true;
        public bool ScanSignaturesInStartup { get; set; } = true;
        public List<string> Trusted { get; set; } = new();   // chaves de alertas ignorados

        // Monitor de mineração
        public bool MinerAlerts { get; set; } = true;
        public int MinerCpuThreshold { get; set; } = 40;     // %
        public int MinerGpuThreshold { get; set; } = 50;     // %

        // Sistema
        public bool CloseToTray { get; set; } = true;
        public bool StartWithWindows { get; set; } = false;
        public bool TrayHintShown { get; set; } = false;
        public DateTime LastSmartScan { get; set; }

        public static string DataDir => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "THGuard");
        static string FilePath => Path.Combine(DataDir, "settings.json");

        public static Settings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var s = JsonSerializer.Deserialize<Settings>(File.ReadAllText(FilePath)) ?? new Settings();
                    s.Trusted ??= new();
                    return s;
                }
            }
            catch { }
            return new Settings();
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(DataDir);
                File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch { }
        }
    }
}
