using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace THGuard
{
    /// <summary>
    /// Logo recolorível: cada parte (principal = vermelho, secundária = prata) é uma
    /// máscara pintada com LogoPrimaryBrush / LogoSecondaryBrush + uma camada de sombra
    /// que preserva o degradê original.
    /// Kind = "emblem" (TH com arco) ou "wordmark" (texto TH Reduct).
    /// </summary>
    public class LogoView : Grid
    {
        public static readonly DependencyProperty KindProperty = DependencyProperty.Register(
            nameof(Kind), typeof(string), typeof(LogoView),
            new PropertyMetadata("emblem", (d, _) => ((LogoView)d).Build()));

        public string Kind
        {
            get => (string)GetValue(KindProperty);
            set => SetValue(KindProperty, value);
        }

        public LogoView()
        {
            RenderOptions.SetBitmapScalingMode(this, BitmapScalingMode.HighQuality);
            Build();
        }

        void Build()
        {
            Children.Clear();
            AddColor("s_mask", "LogoSecondaryBrush");
            AddShade("s_shade");
            AddColor("p_mask", "LogoPrimaryBrush");
            AddShade("p_shade");
        }

        BitmapImage Img(string layer) =>
            new(new Uri($"pack://application:,,,/Assets/{Kind}_{layer}.png"));

        void AddColor(string layer, string brushKey)
        {
            var r = new Rectangle { OpacityMask = new ImageBrush(Img(layer)) { Stretch = Stretch.Fill } };
            r.SetResourceReference(Shape.FillProperty, brushKey);
            Children.Add(r);
        }

        void AddShade(string layer) =>
            Children.Add(new Image { Source = Img(layer), Stretch = Stretch.Fill });
    }
}
