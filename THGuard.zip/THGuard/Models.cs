using System;
using System.Windows.Media;

namespace THGuard
{
    public enum Severity { Info = 0, Low = 1, Medium = 2, High = 3 }

    public enum FixKind
    {
        None, KillProcess, Quarantine, DisableStartup, RemoveExclusion, EnableRealtime, UpdateSignatures,
        EnablePua, EnableFirewall, EnableUac, DisableProxy, CleanHosts, RemoveWmi, EnableSmartScreen
    }

    public static class Sev
    {
        static SolidColorBrush B(string hex) { var b = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex)); b.Freeze(); return b; }
        public static readonly SolidColorBrush HighBrush = B("#EF4444"), MediumBrush = B("#F59E0B"), LowBrush = B("#3B82F6"), InfoBrush = B("#6B7280"), OkBrush = B("#10B981");

        public static string Text(Severity s) => s switch
        {
            Severity.High => "ALTO",
            Severity.Medium => "MÉDIO",
            Severity.Low => "BAIXO",
            _ => "INFO"
        };

        public static SolidColorBrush Brush(Severity s) => s switch
        {
            Severity.High => HighBrush,
            Severity.Medium => MediumBrush,
            Severity.Low => LowBrush,
            _ => InfoBrush
        };
    }

    /// <summary>Um problema encontrado numa verificação.</summary>
    public class Finding : Observable
    {
        string _status = "";
        bool _done;

        public Severity Severity { get; init; }
        public string Category { get; init; } = "";
        public string Title { get; init; } = "";
        public string Detail { get; init; } = "";
        public string Path { get; init; } = "";
        public int Pid { get; init; }
        public string Key { get; init; } = "";
        public FixKind Fix { get; init; }
        public string FixLabel { get; init; } = "";
        public object? Tag { get; init; }

        public string SeverityText => Sev.Text(Severity);
        public SolidColorBrush SeverityBrush => Sev.Brush(Severity);
        public bool HasFix => Fix != FixKind.None && !Done;
        public bool HasPath => Path.Length > 0;
        public string Status { get => _status; set => Set(ref _status, value); }
        public bool Done { get => _done; set { if (Set(ref _done, value)) Raise(nameof(HasFix)); } }
    }

    /// <summary>Uma entrada de inicialização automática (autorun).</summary>
    public class StartupEntry : Observable
    {
        string _signer = "", _status = "";
        bool _enabled = true;
        Severity _risk;
        string _reasons = "";

        public string Source { get; init; } = "";
        public string Name { get; init; } = "";
        public string Command { get; init; } = "";
        public string FilePath { get; init; } = "";
        public string Location { get; init; } = "";

        // Para desativar/restaurar
        public string RegHive { get; init; } = "";
        public string RegKey { get; init; } = "";
        public string RegValue { get; init; } = "";
        public string TaskName { get; init; } = "";
        public string ServiceName { get; init; } = "";

        public bool Enabled { get => _enabled; set => Set(ref _enabled, value); }
        public string Signer { get => _signer; set => Set(ref _signer, value); }
        public string Status { get => _status; set => Set(ref _status, value); }
        public Severity Risk { get => _risk; set { if (Set(ref _risk, value)) { Raise(nameof(RiskText)); Raise(nameof(RiskBrush)); } } }
        public string Reasons { get => _reasons; set => Set(ref _reasons, value); }
        public string RiskText => Risk == Severity.Info ? "OK" : Sev.Text(Risk);
        public SolidColorBrush RiskBrush => Risk == Severity.Info ? Sev.OkBrush : Sev.Brush(Risk);
        public bool FileMissing => FilePath.Length > 0 && !System.IO.File.Exists(FilePath);
        public bool CanDisable => RegValue.Length > 0 || TaskName.Length > 0 || ServiceName.Length > 0 || Source == "Pasta Inicializar";
    }

    /// <summary>Linha do monitor de processos.</summary>
    public class ProcRow : Observable
    {
        double _cpu, _gpu, _mem;
        string _signer = "", _reasons = "", _conn = "";
        Severity _risk;

        public int Pid { get; init; }
        public string Name { get; init; } = "";
        public string Path { get; init; } = "";
        public string CommandLine { get; init; } = "";
        public int ParentPid { get; init; }
        public bool HasWindow { get; set; }

        public double Cpu { get => _cpu; set { if (Set(ref _cpu, value)) Raise(nameof(CpuText)); } }
        public double Gpu { get => _gpu; set { if (Set(ref _gpu, value)) Raise(nameof(GpuText)); } }
        public double MemoryMB { get => _mem; set { if (Set(ref _mem, value)) Raise(nameof(MemText)); } }
        public string Signer { get => _signer; set => Set(ref _signer, value); }
        public string Reasons { get => _reasons; set => Set(ref _reasons, value); }
        public string Connections { get => _conn; set => Set(ref _conn, value); }
        public Severity Risk { get => _risk; set { if (Set(ref _risk, value)) { Raise(nameof(RiskText)); Raise(nameof(RiskBrush)); } } }

        public int HighUsageSamples { get; set; }
        public string CpuText => $"{Cpu:0}%";
        public string GpuText => Gpu >= 0.5 ? $"{Gpu:0}%" : "—";
        public string MemText => MemoryMB >= 1024 ? $"{MemoryMB / 1024:0.0} GB" : $"{MemoryMB:0} MB";
        public string RiskText => Risk == Severity.Info ? "OK" : Sev.Text(Risk);
        public SolidColorBrush RiskBrush => Risk == Severity.Info ? Sev.OkBrush : Sev.Brush(Risk);
    }

    public class QuarantineItem
    {
        public string Id { get; set; } = "";
        public string Kind { get; set; } = "Arquivo";   // Arquivo | Registro | Tarefa | Serviço
        public string OriginalPath { get; set; } = "";
        public string Name { get; set; } = "";
        public string Reason { get; set; } = "";
        public string Sha256 { get; set; } = "";
        public DateTime Date { get; set; }
        public long Size { get; set; }

        // Para itens de registro / tarefa / serviço
        public string RegHive { get; set; } = "";
        public string RegKey { get; set; } = "";
        public string RegValue { get; set; } = "";
        public string RegData { get; set; } = "";
        public string TaskName { get; set; } = "";
        public string ServiceName { get; set; } = "";
        public int ServiceStart { get; set; }

        public string SubText => $"{Kind} · {Date:dd/MM/yyyy HH:mm} · {Reason}";
    }

    public class ThreatRecord
    {
        public string Name { get; init; } = "";
        public string Resource { get; init; } = "";
        public DateTime Date { get; init; }
        public string Severity { get; init; } = "";
        public string Status { get; init; } = "";
        public string SubText => $"{Date:dd/MM/yyyy HH:mm} · {Severity} · {Status}";
    }

    public class CheckItem : Observable
    {
        bool _ok;
        string _value = "";
        public string Name { get; init; } = "";
        public string Description { get; init; } = "";
        public FixKind Fix { get; set; }
        public string FixLabel { get; set; } = "Corrigir";
        public bool Ok { get => _ok; set { if (Set(ref _ok, value)) { Raise(nameof(Brush)); Raise(nameof(CanFix)); Raise(nameof(Glyph)); } } }
        public string Value { get => _value; set => Set(ref _value, value); }
        public bool CanFix => !Ok && Fix != FixKind.None;
        public SolidColorBrush Brush => Ok ? Sev.OkBrush : Sev.MediumBrush;
        public string Glyph => Ok ? "" : "";
    }
}
